/* REGICIDE PVP — 07-ai.js */
// ---------- spawn the armies ----------
const NAMES=["Aldric","Berta","Cedric","Dagny","Edmund","Freya","Godwin","Hilda","Ivo","Jorunn","Kettil","Leofric","Maren","Nils","Oswin","Petra","Quenna","Ragnar","Sigrid","Torvald","Una","Vidar","Wyn","Ysolde","Zorka"];
// ---------- v124 "ALEXANDER THE GREAT" ----------
// John's format, and everyone on the field gets one — the kill feed reads properly now
// ("Aldric the Bold slew Cassius the Vigilant") and the scoreboard looks like a roll of warriors
// rather than a class register. Rolled once and FIXED for the match: an epithet that shifted as you
// advanced would leave teammates tracking a name that no longer exists.
//
// The epithet is chosen by the SAME index as the name, not independently, so a given warrior is the
// same warrior on every machine. That matters more than it looks: names ride the wire as strings on
// join, but bots are named locally from their unit id on host AND guest, and two machines disagreeing
// about who "Ragnar the Unbroken" is would show up in every kill message.
const EPITHETS=["the Great","the Bold","the Unbroken","the Vigilant","the Grim","the Swift",
  "the Stout","the Red","the Wanderer","the Younger","the Elder","the Fell","the Keen",
  "the Quiet","the Wolf","the Hammer","the Proud","the Lucky","the Sly","the Iron",
  "the Fearless","the Ready","the Stern","the Wise","the Bear","the Fair","the Hardy",
  "the Long-Armed","the Black","the Steadfast"];
function mkEpithet(i){return EPITHETS[i%EPITHETS.length];}
function mkName(i){
  const base=NAMES[i%NAMES.length];
  // the pools are coprime-ish in length (25 names, 30 epithets), so the pairing does not repeat
  // until 750 warriors — comfortably past a 100-unit field
  const ep=EPITHETS[(i*7+Math.floor(i/NAMES.length))%EPITHETS.length];
  return base+" "+ep;
}
function spawnTeam(team,count,nameOff){
  const tc=TCPOS[team];
  for(let i=0;i<count;i++){
    const a=Math.random()*Math.PI*2,r=13+Math.random()*12; // clear of the 2x TC
    const u=makeUnit(team,"villager",tc[0]+Math.cos(a)*r,tc[1]+Math.sin(a)*r,
      {name:mkName(i+nameOff),bot:{role:"citizen",res:(r=>r<0.45?"food":r<0.7?"wood":r<0.9?"gold":"stone")(Math.random())}});
    u.guardA=Math.random()*Math.PI*2; u.guardR=5+Math.random()*8; u.spread=(Math.random()-0.5)*26;
  }
}
player=makeUnit(BLUE,"villager",TCPOS[0][0]+12,6,{isPlayer:true,name:"You"});
kings[BLUE]=makeUnit(BLUE,"king",TCPOS[0][0]+8,-12,{isKing:true,name:"King Osric",bot:{role:"king"}});
kings[RED]=makeUnit(RED,"king",TCPOS[1][0]-8,12,{isKing:true,name:"King Vargus",bot:{role:"king"}});
spawnTeam(BLUE,48,0);   // + you + King Osric = 50
spawnTeam(RED,49,31);   // + King Vargus = 50

// ---------- THE WILDS: nine creep camps — six ring the world's edge, three stand in the field ----------
// v132.7 CREEP_SITES, not CAMPS: this loop wants everywhere creeps LIVE, which is no longer the same
// question as where the border pockets are. See the note at CREEP_SITES in 00-data.js. Nothing else
// in here changes — st.r, st.aggro and the hard leash were already derived from the site's own
// radius, so a 16-radius clearing works out of the box and a 26-radius hollow is unaffected.
// Each camp always creates CREEP_N unit bodies so unit ids stay deterministic across
// host/guest; a 4-pack simply leaves the fifth dead. Pack type is rolled per machine
// and reconciled by applyWorld/snapshots — the HOST's roll is the truth.
const campStates=[];
for(let ci=0;ci<CREEP_SITES.length;ci++){
  const C=CREEP_SITES[ci];
  if(C.boss){ // THE SOUTHERN SHORE: starts as an empty wreck — the raid lands at 15:00
    const st={i:ci,x:C.x,z:C.z,r:C.r,aggro:C.r-2,boss:true,kind:"viking",
              waiting:true,respawnAt:BOSS_RESPAWN,chest:null,chestKind:null,chestB:null,chestKindB:null,creeps:[]};
    for(let k=0;k<BOSS_N;k++){ // body 0 is the chieftain; all start dead on the sand
      const isBoss=k===0;
      const a=((k-1)/(BOSS_N-1))*Math.PI*2, r=isBoss?0:(C.r*0.27+((k%2)*C.r*0.08)); // the war band rings its chieftain, scaled to the bay
      const u=makeUnit(NEUTRAL,isBoss?"vikingboss":"viking",C.x+Math.cos(a)*r,C.z+Math.sin(a)*r,
        {name:isBoss?"Viking Chieftain":"Viking Raider",bot:{role:"creep",camp:st,post:{a,r}}});
      u.respawnT=Infinity; u.alive=false; u.root.visible=false;
      st.creeps.push(u);
    }
    campStates.push(st); continue;
  }
  const st={i:ci,x:C.x,z:C.z,r:C.r,aggro:C.r-2.5,kind:Math.random()<0.5?"wolf":"barbarian",
            waiting:false,respawnAt:0,chest:null,chestKind:null,chestB:null,chestKindB:null,creeps:[]};
  const n=4+((Math.random()<0.5)?0:1);
  for(let k=0;k<CREEP_N;k++){
    const a=(k/CREEP_N)*Math.PI*2+0.6, r=C.r*0.35+(k%2)*(C.r*0.17); // the pack spreads through its doubled hollow
    const u=makeUnit(NEUTRAL,st.kind,C.x+Math.cos(a)*r,C.z+Math.sin(a)*r,
      {name:st.kind==="wolf"?"Wild Wolf":"Barbarian",bot:{role:"creep",camp:st,post:{a,r}}});
    u.respawnT=Infinity; // the camp manager rules creep rebirth, never the town clock
    if(k>=n){u.alive=false;u.root.visible=false;}
    st.creeps.push(u);
  }
  campStates.push(st);
}
// the treasure: a chest at the camp's heart — pure visuals here, state lives on st
function _chestShow(st,kind,slotB){ // slotB: the boss shore drops TWO chests, side by side
  _chestHide(st,slotB);
  const g=new THREE.Group();
  const base=new THREE.Mesh(new THREE.BoxGeometry(1.5,0.9,1.0),texturedMat("wood",0x7a5230)); base.position.y=0.45; base.castShadow=true; g.add(base);
  const lid=new THREE.Mesh(new THREE.CylinderGeometry(0.5,0.5,1.5,8,1,false,0,Math.PI),texturedMat("wood",0x8a6240)); lid.rotation.z=Math.PI/2; lid.position.y=0.9; g.add(lid);
  const band=new THREE.Mesh(new THREE.BoxGeometry(1.56,0.16,1.04),plainMat(0xe0c23a)); band.position.y=0.62; g.add(band);
  const lock=new THREE.Mesh(new THREE.BoxGeometry(0.24,0.3,0.1),plainMat(0xe0c23a)); lock.position.set(0,0.62,0.53); g.add(lock);
  const gleam=new THREE.Mesh(new THREE.SphereGeometry(0.22,6,5), // read the prize at a glance: red = food, gold = gold
    new THREE.MeshBasicMaterial({color:kind==="food"?0xd23c2f:0xffd24a})); gleam.position.y=1.35; g.add(gleam);
  const off=st.boss?(slotB?2.6:-2.6):0; // the shore's pair sit shoulder to shoulder at the fire ring
  g.position.set(st.x+off,terrainHeight(st.x+off,st.z),st.z);
  scene.add(g);
  if(slotB){st.chestB=g;st.chestKindB=kind;}else{st.chest=g;st.chestKind=kind;}
}
function _chestHide(st,slotB){
  if(slotB){ if(st.chestB){scene.remove(st.chestB);st.chestB=null;} st.chestKindB=null; }
  else     { if(st.chest){scene.remove(st.chest);st.chest=null;}   st.chestKind=null;  }
}
function spawnCampChest(st,kind,slotB){ // host/solo: show + tell the guests
  _chestShow(st,kind,slotB);
  if(typeof NET!=="undefined"&&NET.mode==="host")NET.bcast({t:"chest",i:st.i,k:kind,s:slotB?1:0});
}
function clearCampChest(st,slotB){
  _chestHide(st,slotB);
  if(typeof NET!=="undefined"&&NET.mode==="host")NET.bcast({t:"chest",i:st.i,k:null,s:slotB?1:0});
}
function collectCampChest(st,e,slotB){
  const kind=slotB?st.chestKindB:st.chestKind, amt=st.boss?BOSS_CHEST:CAMP_CHEST;
  stock[e.team][kind]+=amt;
  awardPts(e,amt); // same rate a deposit pays: a point per resource
  if(typeof questProgress==="function")questProgress(e,"chest"); // TREASURE HUNTER
  const who=e.isPlayer?"You":e.name;
  const txt=(e.team===MYTEAM?("⚑ "+who+" claimed a camp treasure: +"+amt+" "+kind+"!")
                            :("The "+TEAMNAME[e.team]+" army plundered a camp treasure (+"+amt+" "+kind+")."));
  msg(txt,e.team===MYTEAM?"blue":"gold");
  if(typeof Sound!=="undefined")Sound.play("chest",{x:st.x,z:st.z}); // v100: treasure-open reward
  if(typeof NET!=="undefined"&&NET.mode==="host")NET.bcast({t:"note",m:"⚑ "+who+" ("+TEAMNAME[e.team]+") claimed a camp treasure: +"+amt+" "+kind+"!",tone:"gold"});
  clearCampChest(st,slotB);
  updateResHud();
}
function campNewWave(st){ // fresh fangs: roll the pack anew
  st.waiting=false;
  st.part=null; // v132.28: a new pack, a new list — nobody carries credit across waves
  if(st.boss){ // THE RAID LANDS: the chieftain and all ten raiders storm ashore
    for(let k=0;k<st.creeps.length;k++){
      const u=st.creeps[k], post=u.bot.post;
      if(u.hp!==u.maxHp||u.cls)setClassStats(u); // full war-strength (cls never changes here)
      u.alive=true;u.corpse=false;u.dieT=0;u.respawnT=Infinity;
      u.body.rotation.x=0;u.root.visible=true;
      const sx=st.x+Math.cos(post.a)*post.r, sz=st.z+Math.sin(post.a)*post.r;
      u.root.position.set(sx,terrainHeight(sx,sz),sz);
      puff(sx,1.6,sz,0xd8dde2);
    }
    const m="⚔ A VIKING RAID storms the SOUTHERN SHORE — a chieftain and his war band guard twin treasures!";
    msg(m,"warn");
    if(typeof Sound!=="undefined")Sound.play("raid"); // v103: the dark gong — a raid has landed
    if(typeof Sound!=="undefined"&&Sound.voxChorus)Sound.voxChorus(st.x,st.z,3); // v109: the war band roars ashore (positional — near the bay you HEAR them)
    if(typeof NET!=="undefined"&&NET.mode==="host"){NET.bcast({t:"note",m,tone:"warn"});NET.bcast({t:"snd",k:"raid"});NET.bcast({t:"snd",k:"__chorus",x:st.x,z:st.z});}
    return;
  }
  st.kind=Math.random()<0.5?"wolf":"barbarian";
  const n=4+((Math.random()<0.5)?0:1);
  for(let k=0;k<st.creeps.length;k++){
    const u=st.creeps[k], post=u.bot.post;
    if(k<n){
      u.name=st.kind==="wolf"?"Wild Wolf":"Barbarian";
      if(u.cls!==st.kind)setClass(u,st.kind); else setClassStats(u);
      u.alive=true;u.corpse=false;u.dieT=0;u.respawnT=Infinity;
      u.body.rotation.x=0;u.root.visible=true;
      const sx=st.x+Math.cos(post.a)*post.r, sz=st.z+Math.sin(post.a)*post.r;
      u.root.position.set(sx,terrainHeight(sx,sz),sz);
      puff(sx,1.4,sz,0x9a8f7a);
    }else{ // the pack came up short — this body stays in the earth
      u.alive=false;u.corpse=false;u.dieT=0;u.root.visible=false;u.respawnT=Infinity;
    }
  }
}
function campTick(dt){ // host/solo only — guests watch it all arrive by snapshot + event
  for(const st of campStates){
    for(const slotB of (st.boss?[false,true]:[false])){ // first boot on a treasure takes it — steals welcome
      if(!(slotB?st.chestB:st.chest))continue;
      const cx=st.boss?(st.x+(slotB?2.6:-2.6)):st.x;
      for(const e of units){
        if(!e.alive||e.team===NEUTRAL)continue;
        if(dist2(e.root.position.x,e.root.position.z,cx,st.z)<2.6*2.6){collectCampChest(st,e,slotB);break;}
      }
    }
    if(st.waiting){
      if(T>=st.respawnAt){
        if(st.chest)clearCampChest(st,false); // unclaimed treasure is dragged off by the new pack
        if(st.chestB)clearCampChest(st,true);
        campNewWave(st);
      }
      continue;
    }
    let alive=0; for(const c of st.creeps)if(c.alive)alive++;
    if(alive===0){ // pack wiped: drop the loot, start the clock
      st.waiting=true; st.respawnAt=T+(st.boss?BOSS_RESPAWN:CAMP_RESPAWN);
      campPayParticipants(st); // v132.28: XP to everyone who fought it, before the loot lands
      if(st.boss){ // the raid is broken: TWIN chests — 500 food and 500 gold
        spawnCampChest(st,"food",false);
        spawnCampChest(st,"gold",true);
        const m="⚑ The VIKING RAID is broken! Twin chests of plunder lie by the wreck — first come, first served.";
        msg(m,"gold");
        if(typeof NET!=="undefined"&&NET.mode==="host")NET.bcast({t:"note",m,tone:"gold"});
      }else spawnCampChest(st,st.kind==="wolf"?"food":"gold",false);
    }
  }
}
// v132.28 THE RECKONING. Called once, on the frame the last creep falls. Pays every human who
// put damage into the pack: 1 for a wild camp, CAMP_XP_BOSS for the Viking raid — as BOTH XP and
// levels (John's ruling), matching what a finished quest pays. Level clamps at XP_MAX_LVL, XP
// does not. Note the raid pays 15 of a 25 cap, so two raids close a player's Town Board for the
// rest of that life — questPick refuses at the cap (09-main.js).
const CAMP_XP=1, CAMP_XP_BOSS=15;
function campPayParticipants(st){
  const list=st.part; st.part=null;
  if(!list||!list.length)return;
  const gain=st.boss?CAMP_XP_BOSS:CAMP_XP;
  for(const u of list){
    if(!u||!u.alive)continue;                       // a corpse holds no XP — death already took it
    if(typeof hasProg!=="function"||!hasProg(u))continue;   // v134.2: soldiers, human or not
    if(!isHuman(u)){ // v134.2 an NPC takes the same award, and SPENDS it — it has no forge to visit
      if(typeof npcAdvance==="function")npcAdvance(u,gain);
      continue;                                             // …and no HUD, quest or sync to notify
    }
    // v132.28.1 (John): participation advances the player exactly as a finished quest does —
    // XP *and* level. Level clamps at the cap the same way completeQuest clamps it; XP does not
    // clamp, because it is a spendable currency and an uncapped XP faucet is what keeps the forge
    // reachable once the level cap is reached.
    u.xp=(u.xp||0)+gain;
    const _lv0=u.lvl||0;
    u.lvl=Math.min(XP_MAX_LVL,_lv0+gain);
    const _got=u.lvl-_lv0;                    // report what was ACTUALLY gained, not the nominal award
    if(typeof questNotify==="function")
      questNotify(u,(st.boss?"⚑ THE RAID IS BROKEN":"⚑ CAMP CLEARED")+" — +"+_got+" level"+
        (_got===1?"":"s")+" & +"+gain+" XP for your part in it. Spend the XP at the Blacksmith."+
        (u.lvl>=XP_MAX_LVL&&_got>0?" You are at the LEVEL CAP — the Town Board has no more work for you this life.":""),"gold");
    if(typeof questProgress==="function")questProgress(u,"camp_wipe"); // CAMP BREAKER, for every participant
    if(typeof syncQuest==="function")syncQuest(u);
    if(typeof syncBuffs==="function")syncBuffs(u);
    if(u.isPlayer&&typeof updateQuestHud==="function")updateQuestHud();
  }
}
// creep brain: guard the camp, savage intruders, never step past the pocket's edge
function updateCreep(u,dt){
  const st=u.bot.camp;
  const px=u.root.position.x,pz=u.root.position.z;
  let t=null,bd=1e9; // nearest intruder INSIDE the aggro ring (per-camp: the boss shore casts a wider net)
  // v132.10 …and a WOKEN camp reaches further, but only as far as whoever is hitting it. Extending
  // by the flat CAMP_WAKE_REACH would put an interior camp's scan at 35 from centre — past the
  // Viking road at 29.7 — so poking a camp would set the pack on a passing trade cart. Reaching to
  // the threat's own distance plus 4, capped, cannot.
  const woke=st.wake&&T<st.wake;
  let agg=st.aggro||CAMP_AGGRO;
  if(woke&&st.threat&&st.threat.alive){
    const td=Math.hypot(st.threat.root.position.x-st.x,st.threat.root.position.z-st.z);
    agg=Math.max(agg,Math.min(td+4,agg+CAMP_WAKE_REACH));
  }
  for(const e of units){
    if(!e.alive||e.team===NEUTRAL||e.garrison)continue;
    if(dist2(e.root.position.x,e.root.position.z,st.x,st.z)>agg*agg)continue;
    const d=dist2(px,pz,e.root.position.x,e.root.position.z);
    if(d<bd){bd=d;t=e;}
  }
  // v110 THE WOLVES: wolf camps HOWL — often on the hunt, rarely at rest (idle howls carry
  // the wilds' dread to anyone passing near). Human growls now belong to the human camps only.
  if(st.kind==="wolf"){
    if(!u._hwT||T>u._hwT){
      u._hwT=T+(t?(10+Math.random()*8):(25+Math.random()*35));
      if(typeof Sound!=="undefined")Sound.play("wolfhowl",{x:px,z:pz});
      if(typeof NET!=="undefined"&&NET.mode==="host")NET.bcast({t:"snd",k:"wolfhowl",x:px,z:pz});
    }
  }
  if(t){
    // v109 THE VOICES: the (human) wilds snarl while they hunt — one growl every ~6-10s per creep
    if(st.kind!=="wolf"&&(!u._grT||T>u._grT)){u._grT=T+6+Math.random()*4;
      if(typeof Sound!=="undefined")Sound.play("vgrowl",{x:px,z:pz});
      if(typeof NET!=="undefined"&&NET.mode==="host")NET.bcast({t:"snd",k:"vgrowl",x:px,z:pz});}
    const d=Math.sqrt(bd);
    if(d>u.rng*0.8)moveToward(u,t.root.position.x,t.root.position.z,dt,u.rng*0.7);
    else{
      u.facing=Math.atan2(t.root.position.x-px,t.root.position.z-pz);
      tryAttack(u);
    }
  }else{
    // calm: drift back to the post; wounds knit while nobody trespasses (anti-poke regen)
    const post=u.bot.post, hx=st.x+Math.cos(post.a)*post.r, hz=st.z+Math.sin(post.a)*post.r;
    if(dist2(px,pz,hx,hz)>2.2*2.2)moveToward(u,hx,hz,dt,1.4);
    else{u.moving=false; if(!u.bot.wt||T>u.bot.wt){u.bot.wt=T+2+Math.random()*3;u.facing=Math.random()*Math.PI*2;}}
    if(u.hp<u.maxHp){u.hp=Math.min(u.maxHp,u.hp+u.maxHp*0.08*dt);setBar(u.bar,u.hp/u.maxHp);}
  }
  // the hard leash: paws never leave the camp circle, no matter the shoving
  // v132.10 …except while the camp is awake, when it gives CAMP_WAKE_CHASE. Seeing the slinger is
  // worth nothing if the paws still stop at r-1.2: on an interior camp the leash is 9.8 and a
  // slinger shooting from 18 would be watched, angrily, from inside the fence. 21.8 reaches him.
  // It snaps back the moment the camp settles, and the calm branch above walks them home.
  const dx=u.root.position.x-st.x,dz=u.root.position.z-st.z,dd=Math.hypot(dx,dz);
  const lim=(st.r||CAMP_R)-1.2+(woke?CAMP_WAKE_CHASE:0);
  if(dd>lim){u.root.position.x=st.x+dx/dd*lim;u.root.position.z=st.z+dz/dd*lim;}
}

// ---------- team AI directors ----------
let rosterAccum=0;
// v94: humans on a team keep its marshal on the supportive "normal" brain;
// pure-AI teams answer to the solo/co-op difficulty dial.
function teamHasHuman(team){
  if(typeof player!=="undefined"&&player&&player.isPlayer&&player.team===team&&
     (typeof NET==="undefined"||NET.mode!=="guest"))return true;
  if(typeof NET!=="undefined"&&NET.mode==="host")
    for(const k in NET.remotes){const r=NET.remotes[k];if(r.unit&&r.unit.team===team)return true;}
  return false;
}
function diffFor(team){return teamHasHuman(team)?"normal":aiDifficulty;}
function mkDirector(team){ // v94: every marshal rolls a PERSONALITY
  const keys=Object.keys(PERSONALITIES);
  const pers=keys[(Math.random()*keys.length)|0];
  return{team,pers,nextThink:2+Math.random()*2,nextConv:40+Math.random()*8,
    nextRaid:PERSONALITIES[pers].raidAt+Math.random()*30,raidUntil:0};
}
const directors=[mkDirector(BLUE),mkDirector(RED)];
function countBld(team,type){let n=0;for(const b of buildings)if(b.alive&&b.built&&b.team===team&&b.type===type)n++;return n;}
// v134.9 THE TOWN'S OWN TOWERS, WHICH IS NOT THE SAME SET AS "every Guard Tower this team owns".
// A tower raised over a square (v134.6) carries bazTower and is paid for out of a different
// allowance with a different stone floor; counting it against P.towers spends the town's budget on
// the frontier's building. Includes sites still under construction, exactly as countBld does —
// a marshal that has one going up should not order a second.
function countScreenTowers(team){
  let n=0;
  for(const b of buildings)if(b.alive&&b.team===team&&b.type==="tower"&&!b.bazTower)n++;
  return n;
}
function pendingBld(team){return buildings.filter(b=>b.alive&&b.team===team&&!b.built);}
function affordKeep(team,cost,rf,rg){
  return stock[team].food>=(cost.food||0)+rf&&stock[team].gold>=(cost.gold||0)+rg&&
    stock[team].stone>=(cost.stone||0)&&stock[team].wood>=(cost.wood||0);
}
// v134.9 WHERE THE KINGS ROAD IS, AT A GIVEN x. roadPoint's x is LINEAR in t — it interpolates
// TCPOS[0][0] to TCPOS[1][0] — so t is recoverable by division and the z falls straight out of the
// same function the plazas, the tree-clearing corridor and the bazaar sites already share. The AI
// used to carry the answer as the literal 6, which was right for a map two reworks ago; it is 7.98
// at the wall line the turtle plans first and 13.64 at the last of its three retries. Two
// derivations of one number is how a gate ends up somewhere the road isn't.
function roadZAt(x){
  const A0=TCPOS[0],B0=TCPOS[1];
  const span=(B0[0]-A0[0])||1;
  const t=Math.max(0,Math.min(1,(x-A0[0])/span));
  return roadPoint(t).z;
}
function findSpot(team,type){
  const tc=TCPOS[team];
  for(let i=0;i<50;i++){
    let x,z;
    // v134.1 EVERY RING MOVES OUT WITH THE FARM RING. These sampled 16-42 (towers), 12-24 (farms)
    // and 11-37 (everything else) from the throne, and validFor now refuses the inside of all
    // three. Fifty attempts against a ring that is mostly illegal is an AI that quietly stops
    // building — the 00-data.js note at BLD.castle records that exact failure costing a release —
    // so the samplers are moved rather than left to fail. Areas are kept comparable: the old
    // general annulus spanned 1248 units of r-squared, the new one 1360.
    if(type==="tower"){
      // v134.9 A SCREEN STANDS WHERE THEY WALK. This was z = (random-0.5)*66, i.e. anywhere in
      // -33..+33 on a map 304 deep, and a Guard Tower reaches 18. Measured over four seeded
      // campaigns, enemy soldiers crossing the defender's own wall line fall within |z| 33 only
      // 31.9% of the time and within 25 of a LANE_Z 93.9% of the time — the lanes ARE the traffic,
      // because assignLane deals every raid and every band one of the five. Counting sightings
      // actually inside a built tower's reach, the shipped screen intercepted 11.9%.
      // DEALT, NOT SAMPLED: LANE_Z is ordered centre-out [0, 48, -48, 106, -106], so the first
      // tower screens the Kings Road, the next two the flanks, and a turtle's last two reach the
      // far lanes. Random placement clusters; a deal spreads. The jitter keeps two towers on one
      // lane from stacking when the count laps the table.
      // Two draws here, two before — the seeded window (invariant #2) cannot move on a count.
      const _lane=LANE_Z[countScreenTowers(team)%LANE_Z.length];
      x=tc[0]+(team===BLUE?1:-1)*(TC_RING+2+Math.random()*24);
      z=_lane+(Math.random()-0.5)*20;   // LANE_Z is MAP z, not town-relative — laneTarget reads it the same way
    }else if(type==="farm"){ // the fields ARE the ring
      const a=Math.random()*Math.PI*2,r=TC_FARM_MIN+0.5+Math.random()*(TC_RING-TC_FARM_MIN-1.5);
      x=tc[0]+Math.cos(a)*r; z=tc[1]+Math.sin(a)*r;
    }else{
      const a=Math.random()*Math.PI*2,r=TC_RING+1+Math.random()*17;
      x=tc[0]+Math.cos(a)*r; z=tc[1]+Math.sin(a)*r*0.85;
    }
    const eg=BLD[type].r+2.6; // every side of the plot stays hammer-reachable
    x=Math.max(-MAP.x+eg,Math.min(MAP.x-eg,x)); z=Math.max(-MAP.z+eg,Math.min(MAP.z-eg,z));
    if(validFor(type,x,z,team))return{x,z};
  }
  return null;
}
function idleCitizen(team){
  for(const u of units)
    if(u.alive&&u.team===team&&u.bot&&!u.isKing&&!u.isPlayer&&!u.remote&&u.cls==="villager"&&!u.task&&!u.convertTo)return u;
  return null;
}
function findSpotNear(team,type,x,z){ // a legal plot in the neighbourhood
  const edge=BLD[type].r+2.6; // room to stand and swing a hammer on EVERY side
  for(let i=0;i<24;i++){
    const a=Math.random()*Math.PI*2, r=6+Math.random()*10;
    const sx=x+Math.cos(a)*r, sz=z+Math.sin(a)*r;
    if(Math.abs(sx)>MAP.x-edge||Math.abs(sz)>MAP.z-edge)continue;
    if(validFor(type,sx,sz,team))return {x:sx,z:sz};
  }
  return null;
}
// ---------- v94: FARM ECONOMY — fields ring the TC, every Storage Pit, and castles ----------
function farmAnchors(team){ // everywhere farmAdjacent will bless a field
  const list=[];
  for(const b of buildings){
    if(!b.alive||b.team!==team)continue;
    // v134.1 the TC's annulus IS the farm ring now — 13-24 sampled ground the rule refuses, and
    // findFarmSpot only gets 60 tries before it gives up and plants a storage pit instead.
    // v134.8: each anchor now carries its own def, because farmFacing has to weigh anchors by how
    // far their COLLIDER reaches and not by how far their centre is. Placement never reads it.
    if(b.type==="towncenter")list.push({x:b.x,z:b.z,rMin:TC_FARM_MIN+0.5,rMax:TC_RING-1,def:b.def,type:b.type});
    else if(b.built&&b.type==="storage_pit")list.push({x:b.x,z:b.z,rMin:13,rMax:19,def:b.def,type:b.type});
    else if(b.built&&b.type==="castle")list.push({x:b.x,z:b.z,rMin:15,rMax:21,def:b.def,type:b.type});
  }
  return list;
}
// v134.8 THE BARN TURNS ITS BACK ON THE THING THE FIELD RINGS. A farm is `flat` — the plot is
// walkable and the only collider it owns is the barn, two discs hanging off the field's local -z
// face at (-4.75,-7.4) r 3.30 x BSCALE 0.6375. Because a farm was never rotated, that offset was
// fixed in WORLD space: every field in the ring pointed its barn the same way, and the ones on the
// wrong arc drove it into the Town Center's box. Measured, the least farm-centre distance clearing
// that box runs 23.45 / 20.80 / 23.75 / 26.75 / 22.20 by age against a ring minimum of 21 — clear
// at age 2 alone. Turned, the same five ages need 13.40 / 10.60 / 13.50 / 15.90 / 11.95.
//
// The transform is the collider's (05-combat.js:2251): local (0,-1) lands at (-sin r, -cos r), so
// rot = -(bearing + PI/2) sends the barn out along the bearing. Pure arithmetic on (x,z) — no
// random draw, so the seeded window is untouched.
//
// MEASURED, NOT GUESSED, once a town has more than one anchor. "Away" is ambiguous the moment a
// field rings both the throne and a Storage Pit, and the obvious rule — face away from the NEAREST
// anchor — is worse than not turning at all: a field ringing a pit just outside TC_RING is nearer
// the pit than the throne, so it turns its back on the pit and drives its barn into the box. Swept
// over every legal plot in the ring with a pit at 30 from the throne, against the box at all five
// ages: unrotated laps 101 of 5,760, nearest-anchor 104, nearest-COLLIDER 26, and the rule below
// none. So the barn does not pick an anchor by distance; it TRIES each anchor's facing and keeps
// the one that leaves it the most room against all of them.
//
// …with the throne as a hard gate rather than one vote among several. Turning away from the Town
// Center always clears the Town Center — that is the second table above, 15.90 needed at the worst
// age against a ring of 21 — so a legal answer always exists, and a facing that would put the barn
// in the throne's box is disqualified however much room it leaves elsewhere. Without that gate a
// mature town (throne, two pits, a castle) still lapped 9 plots in 11,520.
//
// EVERY blockPart, ignoring the age gates: a field planted at Bronze grows a dovecote at Medieval
// and a horse-gin at Enlightenment, and this rotation is chosen ONCE, at placement.
//
// +1.0 ON EVERY REACH because bSurf returns the UNPADDED corner while the collider pads each face
// by 0.7 — a padded box reaches 0.97 further at its corner than bSurf says, and those nine plots
// lived in exactly that shell.
function farmFacing(team,x,z){
  const anch=farmAnchors(team);
  if(!anch.length)return 0;                    // no anchor yet: leave it as it always was
  const PARTS=BLD.farm.blockParts||[], bs=(typeof BSCALE!=="undefined"&&BSCALE.farm)||1;
  let best=0,bestS=-1e9;
  for(const a of anch){
    const rot=-(Math.atan2(z-a.z,x-a.x)+Math.PI/2);
    const c=Math.cos(rot), sn=Math.sin(rot);
    let room=1e9, throne=1e9;
    for(const q of PARTS){
      const qx=q.x*bs, qz=q.z*bs, qr=q.r*bs+0.7;
      const wx=x+qx*c+qz*sn, wz=z-qx*sn+qz*c;  // the collider's own local -> world
      for(const b of anch){
        const g=Math.hypot(wx-b.x,wz-b.z)-(b.def?bSurf(b.def)+1:0)-qr;
        if(g<room)room=g;
        if(b.type==="towncenter"&&g<throne)throne=g;
      }
    }
    const sc=(throne<0)?room-1000:room;        // the throne's box is not one vote among several
    if(sc>bestS){bestS=sc;best=rot;}
  }
  return best;
}
function findFarmSpot(team){ // sample rings around every anchor, not just the TC
  const anchors=farmAnchors(team);
  if(!anchors.length)return null;
  const eg=BLD.farm.r+2.6;
  for(let i=0;i<60;i++){
    const A=anchors[(Math.random()*anchors.length)|0];
    const a=Math.random()*Math.PI*2, r=A.rMin+Math.random()*(A.rMax-A.rMin);
    const x=Math.max(-MAP.x+eg,Math.min(MAP.x-eg,A.x+Math.cos(a)*r));
    const z=Math.max(-MAP.z+eg,Math.min(MAP.z-eg,A.z+Math.sin(a)*r));
    if(validFor("farm",x,z,team))return{x,z};
  }
  return null;
}
function findPitSpotForFarms(team){ // no room left? plant a NEW pit a field's walk out — fresh farm anchor
  const tc=TCPOS[team];
  const eg=BLD.storage_pit.r+2.6;
  for(let i=0;i<40;i++){
    const a=Math.random()*Math.PI*2, r=34+Math.random()*14;
    const x=Math.max(-MAP.x+eg,Math.min(MAP.x-eg,tc[0]+Math.cos(a)*r));
    const z=Math.max(-MAP.z+eg,Math.min(MAP.z-eg,tc[1]+Math.sin(a)*r*0.85));
    if(validFor("storage_pit",x,z,team))return{x,z};
  }
  return null;
}
// v94 HARD AI: read the enemy's army and weight the counter-lines off the RPS wheel
function counterWeights(team,base){
  let eM=0,eA=0,eR=0,eC=0,eS=0;
  for(const e of units){
    if(!e.alive||e.team!==1-team||e.isKing||isWorker(e))continue; // v134.4: carts are not a line to counter
    const l=CLS[e.cls].line;
    if(CLS[e.cls].mounted)eC++;
    else if(l==="melee")eM++;
    else if(l==="anticav")eA++;
    else if(l==="ranged")eR++;
    else if(isSiege(e.cls))eS++;
  }
  const W=Object.assign({},base);
  W.anticav=(W.anticav||2)+eC*1.2;      // spears answer the horse (3.8x)
  W.ranged=(W.ranged||2)+eA*0.8;        // arrows answer the spear (1.8x)
  W.melee=(W.melee||2)+(eR+eS)*0.8;     // swords run down archers, dismantle engines
  W.cavalry=(W.cavalry||2)+eR*0.6+eM*0.5; // the horse tramples bow and blade
  return W;
}
function directorThink(D){
  manageBands(D);
  const team=D.team, P=PERSONALITIES[D.pers]||PERSONALITIES.expand, DF=AI_DIFF[diffFor(team)]||AI_DIFF.normal;
  const ag=teamAge[team];
  // --- the scouts read the enemy marshal's doctrine (~45s in) ---
  if(!D.annT&&T>45){
    D.annT=1;
    const mine=team===MYTEAM;
    msg(mine?("⚑ Your marshal's doctrine — "+P.name.toUpperCase()+": "+P.flavor+".")
            :("Scouts report: the "+TEAMNAME[team]+" marshal "+P.flavor+" — "+P.name.toUpperCase()+"."),
        mine?"blue":"warn");
    if(typeof NET!=="undefined"&&NET.mode==="host")
      NET.bcast({t:"note",m:"Scouts report: the "+TEAMNAME[team]+" marshal "+P.flavor+" — "+P.name.toUpperCase()+".",tone:"gold"});
  }
  // --- advance the age when the doctrine allows ---
  const nxt=AGES[ag+1];
  if(nxt){
    let bufF=P.ageBufF*DF.buf, bufG=P.ageBufG*DF.buf;
    if(teamHasHuman(team)){bufF=Math.max(bufF,380);bufG=Math.max(bufG,150);} // an attentive human gets to press T first
    if(stock[team].food>=nxt.cost.food+bufF&&stock[team].gold>=(nxt.cost.gold||0)+bufG)startAgeResearch(team); // v107: AI pays and waits the same 90s
  }
  // --- construction desires (personality caps; expand keeps three crews busy) ---
  const sites=pendingBld(team);
  if(sites.length<(D.pers==="expand"?3:2)){
    let want=null;
    const barCap=T>240?2:1;
    // v134.9 `have` overrides the count for the one type whose buildings come out of two
    // different purses. Everything else keeps countBld.
    const need=(type,cap,rf,rg,have)=>(BLD[type].age||0)<=ag&&
      ((have===undefined?countBld(team,type):have)<cap)&&
      !sites.some(x=>x.type===type)&&affordKeep(team,BLD[type].cost,rf,rg);
    const farmCap=P.farmsBase+P.farmsPerAge*ag;
    if(need("barracks",barCap,0,0))want="barracks";
    else if(need("farm",farmCap,40,0)){
      const fs=findFarmSpot(team); // TC ring, pit rings, castle rings
      // v134.8: …facing out. makeBuilding has taken a rot since walls needed one; a farm is the
      // first thing to ask for it that is not a wall.
      if(fs){pay(team,BLD.farm.cost);makeBuilding(team,"farm",fs.x,fs.z,false,farmFacing(team,fs.x,fs.z));}
      else if(need("storage_pit",P.pits,80,0)){ // no room for fields: plant a pit to anchor a NEW cluster
        const ps=findPitSpotForFarms(team);
        if(ps){pay(team,BLD.storage_pit.cost);makeBuilding(team,"storage_pit",ps.x,ps.z,false);}
      }
    }
    else if(need("archery_range",1,60,0))want="archery_range";
    else if(need("stable",1,80,20))want="stable";
    else if(need("blacksmith",1,60,0))want="blacksmith"; // v87: the forge rises at Iron — every human gets a place to spend XP
    else if(need("house",Math.min(P.houses,1+Math.floor(T/55)),120+ag*40,0))want="house";
    else if(need("temple",1,150,80))want="temple";
    else if(need("siege_workshop",1,180,120))want="siege_workshop";
    else if(need("watch_tower",2,80,0))want="watch_tower";
    else if(need("castle",P.castles,350,120))want="castle";
    else if(need("market",Math.min(P.markets,(ag>=5?5:ag>=4?3:1)),200,100))want="market";
    // v134.9: …counting the town's OWN towers. This read countBld(team,"tower") through need, so
    // every Guard Tower raised over a square since v134.6 spent one of these. Measured: across four
    // seeded campaigns and eight armies, findSpot placed no screen tower at all.
    else if(need("tower",Math.min(P.towers,Math.floor(T/95)),150+ag*40,60,countScreenTowers(team)))want="tower";
    if(want){
      const s=findSpot(team,want);
      if(s){pay(team,BLD[want].cost);makeBuilding(team,want,s.x,s.z,false);}
    }
  }
  // --- v94 TURTLE: a wall line rises across the front, with a gate on the road ---
  if(P.walls&&ag>=2&&!D.wallsDone&&pendingBld(team).length<3){
    const wt=ag>=4?"fort_wall":ag>=3?"stone_wall":"wood_wall";
    const gt=ag>=4?"fort_gate":ag>=3?"stone_gate":"wood_gate";
    if(!D.wallPlan){ // one straight curtain facing the enemy (30 paces out; farther if the town swallowed it)
      // v134.1: 30 -> 34. The curtain's middle segment sat at exactly TC_RING from the throne, and
      // a wall plan one floating-point rounding away from being refused is a wall plan that will be
      // refused on some machine and not others.
      const tc=TCPOS[team], front=tc[0]+(team===BLUE?1:-1)*(D.wallFront||34);
      // v134.9 AS LONG AS THE WALL HE CAN AFFORD, NOT 96 UNITS AND A SLICE. wallLineSegments cuts a
      // line into round(L/10.9) pieces, so a 96-unit plan became NINE segments and .slice(0,8) then
      // threw the ninth away: a turtle that built every wall it had still ended with a
      // segment-wide hole at one end, every game, by construction. Deriving the length from
      // P.walls makes the plan and the purse the same number — eight walls, eight segments, no
      // truncation. 10.9 is wallLineSegments' own step; keep them together.
      const _half=P.walls*10.9/2;
      D.wallPlan=wallLineSegments(wt,front,tc[1]-_half,front,tc[1]+_half).slice(0,P.walls);
      D.wallPlaced=0;
    }
    if(D.wallPlaced<D.wallPlan.length){
      const s=D.wallPlan[D.wallPlaced];
      if(affordKeep(team,BLD[wt].cost,60,0)&&validFor(wt,s.x,s.z,team)){
        pay(team,BLD[wt].cost);
        makeBuilding(team,wt,s.x,s.z,false,s.rot);
        D.wallPlaced++;
      }else if(!validFor(wt,s.x,s.z,team))D.wallPlaced++; // blocked ground: skip the segment
    }else{
      const anyWall=buildings.some(b=>b.team===team&&b.alive&&b.def.wall&&!b.def.gate);
      // v134.4: THREE steps, not one. This was !D.wallRetry — a single boolean — and on SMOKE_SEED
      // =42 with the v134.4 economy a turtle at age 5 had all eight of its segments refused at 34
      // and all eight again at 44, then set wallsDone with nothing standing. A bigger, older town
      // needs the curtain further out than one step of fourteen; three steps reach 76 from the
      // throne, and a turtle that cannot find room at any of them is genuinely full and stands down.
      if(!anyWall&&(D.wallRetry||0)<3){ // the whole line was inside the town: step 14 paces out
        D.wallRetry=(D.wallRetry||0)+1; D.wallFront=(D.wallFront||30)+14; D.wallPlan=null;
      }else{ // the curtain stands: set the gate into the segment nearest the Kings Road
        let g=null,gd=1e12;
        for(const b of buildings){
          if(b.team!==team||!b.alive||!b.built||!b.def.wall||b.def.gate)continue;
          // v134.9: was Math.abs(b.z-6), "the road runs ~z 6 at the wall line". It runs at 7.98
          // there and at 13.64 at the last of the three retry fronts, and segments are 10.9 apart —
          // so at the far fronts the literal picked the neighbouring segment and the Kings Road ran
          // through a wall instead of through the gate. roadZAt inverts roadPoint; one source.
          const d=Math.abs(b.z-roadZAt(b.x));
          if(d<gd){gd=d;g=b;}
        }
        if(g&&affordKeep(team,BLD[gt].cost,0,0)){pay(team,BLD[gt].cost);placeGateOnWall(g,gt,team);D.wallsDone=true;}
        else if(!g)D.wallsDone=true; // hostile ground everywhere, twice over: stand down
      }
    }
  }
  // --- a storage pit rises wherever the haul has grown long ---
  if(pendingBld(team).length<2&&countBld(team,"storage_pit")<Math.max(3,P.pits)&&affordKeep(team,BLD.storage_pit.cost,0,0)){
    const tc=TCPOS[team];
    for(const u of units){
      if(!u.alive||u.team!==team||!isWorker(u)||!u.bot||!u.bot.node)continue; // v134.4: the ox counts — it works furthest out
      const n=u.bot.node;
      if(dist2(n.x,n.z,tc[0],tc[1])<55*55)continue; // close enough to walk
      let covered=false;
      for(const bl of buildings)
        if(bl.alive&&bl.team===team&&(bl.type==="storage_pit"||bl.type==="castle"||bl.type==="towncenter")&&
           dist2(n.x,n.z,bl.x,bl.z)<30*30){covered=true;break;}
      if(covered)continue;
      const s=findSpotNear(team,"storage_pit",n.x,n.z);
      if(s){pay(team,BLD.storage_pit.cost);makeBuilding(team,"storage_pit",s.x,s.z,false);}
      break;
    }
  }
  // --- v134.6 a Guard Tower rises on each square this team holds ---
  // The band standing on a square goes home when the tour is up; a tower does not. 400 hp, 9 damage
  // at 18 — it will not hold a square against an army, and it is not meant to: it makes taking one
  // cost something, which measured at nothing before this. Age 3 (BLD.tower.age), one site at a
  // time, and a stone floor so the castle and the walls are not eaten by the frontier.
  if(typeof neutralMarkets!=="undefined"&&(BLD.tower.age||0)<=ag&&pendingBld(team).length<2&&
     !pendingBld(team).some(b=>b.type==="tower")&&
     affordKeep(team,BLD.tower.cost,0,0)&&stock[team].stone>=BLD.tower.cost.stone+BAZ_TOWER_STONE){
    for(const m of neutralMarkets){
      if(m.owner!==team)continue;
      let have=0;
      for(const b of buildings)
        if(b.alive&&b.team===team&&b.type==="tower"&&
           dist2(b.x,b.z,m.x,m.z)<Math.pow((m.plaza||8.6)+BAZ_TOWER_GAP+BAZ_TOWER_OUT+2,2))have++;
      if(have>=bazTowerWant(team,m))continue; // v134.10: two, plus one a capture, to four
      const s=bazTowerSpot(team,m);
      if(s){
        pay(team,BLD.tower.cost);
        // v134.9 TAGGED AT BIRTH, not inferred from geometry later: a square changes hands and a
        // tower's distance to it does not, so a budget that re-derives "is this a bazaar tower?"
        // from position would reclassify buildings as the map turns. See countScreenTowers.
        makeBuilding(team,"tower",s.x,s.z,false).bazTower=true;
        if(team===BLUE)msg("A guard tower is raised over your bazaar.","blue");
      }
      break; // one square a think: the builders have to walk out there
    }
  }
  // --- crew the construction sites (2 builders each) ---
  for(const s of pendingBld(team)){
    let crew=0;
    for(const u of units)if(u.alive&&u.task&&u.task.site===s)crew++;
    while(crew<2){const c=idleCitizen(team);if(!c)break;c.task={site:s};crew++;}
  }
  // --- train soldiers from the shared stockpile (doctrine sets the mix & the tempo) ---
  if(T>D.nextConv&&countBld(team,"barracks")>0){
    D.nextConv=T+(P.trainMin+Math.random()*(P.trainMax-P.trainMin))*DF.trainMul;
    const pool=[];
    let priests=0;
    for(const u of units)if(u.alive&&u.team===team&&CLS[u.cls].line==="healer")priests++;
    let siegeAlive=0;
    for(const u of units)if(u.alive&&u.team===team&&isSiege(u.cls))siegeAlive++;
    let W=Object.assign({melee:3,anticav:3,ranged:3,cavalry:3,scoutline:1},P.trainW||{});
    if(DF.counter)W=counterWeights(team,W); // HARD reads the field and counters it
    W.healer=priests<2?1:0;
    W.meleesiege=siegeAlive<4?(W.meleesiege!==undefined?W.meleesiege:1):0;
    W.rangedsiege=siegeAlive<4?(W.rangedsiege!==undefined?W.rangedsiege:2):0;
    for(const type of TRAIN_BUILDINGS){
      if(!countBld(team,type))continue;
      for(const line of linesAt(type,team)){
        const uid=lineUnitFor(line,team);
        if(uid)for(let i=0;i<Math.round(W[line]||0);i++)pool.push({uid,at:type});
      }
    }
    if(pool.length){
      const pick=pool[(Math.random()*pool.length)|0], cls=pick.uid, cost=CLS[cls].cost;
      let vills=0;
      for(const u of units)if(u.alive&&u.team===team&&!u.isKing&&u.cls==="villager")vills++;
      // reserves scale with age AND doctrine — rush spends to the felt, boom banks the next age
      if(vills>P.minVills&&affordKeep(team,cost,P.reserveF+ag*40*DF.buf,P.reserveG+ag*15*DF.buf)){
        const c=idleCitizen(team);
        if(c){pay(team,cost);c.convertTo=cls;c.convertAt=pick.at;}
      }
    }
  }
  // --- markets dispatch trade carts (cap: 2 alive per market) ---
  for(const b of buildings){
    if(!b.alive||!b.built||b.team!==team||b.type!=="market")continue;
    b.cartT=(b.cartT===undefined?150:b.cartT+1);
    if(b.cartT>=180){
      let carts=0;
      for(const u of units)if(u.alive&&u.bot&&u.bot.role==="cart"&&u.bot.home===b)carts++;
      if(carts<2){
        b.cartT=0;
        makeUnit(team,"tradecart",b.x+9,b.z+5,{name:"Trade Cart",bot:{role:"cart",home:b}});
        if(team===BLUE)msg("A trade cart sets out from your Market.","blue");
      }else b.cartT=175; // wait for a slot to free up
    }
  }
  // --- v134.4 the pit yokes an ox when timber is the shortage ---
  // Deliberately shaped like the market's cart rule above rather than like the training pool: a
  // count, a cap and a clock. The ox comes out of idleCitizen — the SAME pool that arms up — which
  // is why OX_MIN_VILLS sits above the training floor rather than at it.
  if(T>(D.oxT||0)&&countBld(team,"storage_pit")>0&&stock[team].wood<OX_WOOD_WANT){
    let oxen=0,vills=0,cutters=0;
    for(const u of units){
      if(!u.alive||u.team!==team||!u.bot||u.isKing)continue;
      if(u.cls==="oxcart")oxen++;
      else if(u.cls==="villager")vills++;
      if(u.bot.node&&u.bot.node.type==="wood")cutters++;
    }
    if(oxen<OX_MAX&&vills>=OX_MIN_VILLS&&cutters>=OX_MIN_CUTTERS&&
       affordKeep(team,CLS.oxcart.cost,P.reserveF,P.reserveG)){
      const c=idleCitizen(team);
      if(c){
        pay(team,CLS.oxcart.cost);
        c.convertTo="oxcart"; c.convertAt="storage_pit"; // the same road a soldier walks to arm up
        D.oxT=T+OX_EVERY;
      }
    }
  }
  // …and the yoke comes OFF when the stores are full. No refund — the 75 gold is spent — but the
  // body goes back to the fields and the mines, which is where a marshal with five thousand wood in
  // the stores and nothing to build needs it. Measured before this rule existed: two oxen filled a
  // team's stores to 14,012 wood by the twentieth minute while that team AGED DOWN relative to the
  // same seed without them — the timber was free and the two bodies were not. It keeps whatever is
  // in the bed: the villager it becomes is over its carry cap on the first frame, so its next act
  // is to walk it home.
  if(T>(D.oxT||0)&&stock[team].wood>OX_WOOD_FULL){
    for(const u of units){
      if(!u.alive||u.team!==team||u.cls!=="oxcart"||!u.bot||u.remote||u.isPlayer)continue;
      // ⚠ NOT WITH A LOADED BED. setClass does not move what is in it, so standing an ox down at
      // 280 logs would leave a villager carrying fourteen times its own cap — and the deposit rule
      // in this file is "no more telepathic deposits", so banking it from wherever it stands is not
      // the answer either. It has an empty bed the instant after every haul; stand it down then.
      if(u.carry.food+u.carry.gold+u.carry.stone+u.carry.wood>0)continue;
      setClass(u,"villager");
      u.bot.res="food"; u.bot.node=null; u.bot.haul=false;
      D.oxT=T+OX_EVERY;
      if(team===BLUE)msg("An ox is unyoked — the stores are full of timber.","blue");
      break;
    }
  }
  // --- raid waves: the doctrine sets when, how many, and how often ---
  const mil=units.filter(u=>u.alive&&u.team===team&&u.bot&&!u.isKing&&!isWorker(u)); // v134.4: an ox is not a raider
  if(T>D.nextRaid&&mil.length>=P.raidMin){
    D.nextRaid=T+(P.raidEvery+Math.random()*P.raidJit)*DF.raidMul;
    D.raidUntil=T+55;
    const frac=Math.min(0.95,P.raidFrac*DF.raidFracMul);
    const party=mil.slice(0,Math.max(Math.min(P.raidMin,mil.length),Math.floor(mil.length*frac)));
    party.forEach(u=>u.raiding=true);
    if(team===RED)msg("⚠ RED ARMY ON THE MARCH — "+party.length+" raiders inbound!","warn");
    else msg("⚑ Your army marches on the Red base — "+party.length+" strong! (G to join the push)","blue");
  }
  if(D.raidUntil&&T>D.raidUntil){
    D.raidUntil=0;
    for(const u of units)if(u.team===team)u.raiding=false;
  }
}

// ---------- bot AI ----------
function nearestEnemyOf(u,maxD){
  let best=null,bd=(maxD||1e4)*(maxD||1e4);
  for(const v of units){
    if(v.team===u.team||!v.alive)continue;
    const d=dist2(u.root.position.x,u.root.position.z,v.root.position.x,v.root.position.z);
    if(d<bd){bd=d;best=v;}
  }
  return best;
}
// ---- v134.4 THE OX AT THE PIT ----
// OX_MAX: oxen a team will yoke. ONE, from John's first playtest of v134.4: "wood is being
//   gathered extremely fast with two NPC oxcarts. Could reduce this to one." The bench said the
//   same thing and I under-weighted it — an ox is four times the axe AND a fifteenth of the
//   walking (300 in the bed against 20, so one trip where a villager makes fifteen), so a second
//   one is not a second villager, it is closer to another fifteen of them on timber alone.
// OX_MIN_VILLS: …and it will not take that body from a small workforce.
// OX_WOOD_WANT / OX_WOOD_FULL: only when TIMBER is the shortage, and off again when it is not.
//   ⚠ THESE ARE READ OFF THE ACTUAL CURVE, not guessed. Sampled every minute of a twenty-minute
//   campaign, a team's wood stock runs: 75 at the whistle, 10-25 by minute one (the opening
//   buildings), 500-900 by two, 1500-2700 by four, then a plateau between 2600 and 4600. The first
//   cut of this rule used 800, which is a window that closes at minute two — before the team has a
//   Storage Pit to yoke at or 75 spare gold — and measured ZERO oxen across four campaigns. A
//   threshold has to be picked against the curve the game actually produces.
// OX_MIN_CUTTERS: …and only for a team that is genuinely working timber.
// OX_EVERY: seconds between yokings, so a windfall does not buy the whole team at once.
// OX_WOOD_FULL: …and it UNYOKES when the bed has done its job. Measured on a twenty-minute
//   campaign: two oxen filled the stores to 7205 wood the marshal had nothing to spend on while
//   the same two bodies were not farming or mining. An ox is a worker as well as a cart, and the
//   hysteresis between WANT and FULL is what stops it flipping back and forth every think.
const OX_MAX=1, OX_MIN_VILLS=10, OX_MIN_CUTTERS=3, OX_WOOD_WANT=3000, OX_WOOD_FULL=5000, OX_EVERY=45;
function botFindNode(u,res){
  let best=null,bd=1e12;
  for(const n of nodes){
    if(n.amount<=0||n.type!==res)continue;
    const homeBias=(u.team===BLUE?(n.x<0?0:12000):(n.x>0?0:12000));
    let crowd=0;
    for(const q of units)if(q.alive&&q.bot&&q.bot.node===n)crowd++;
    const d=dist2(u.root.position.x,u.root.position.z,n.x,n.z)+homeBias+crowd*crowd*450;
    if(d<bd){bd=d;best=n;}
  }
  return best;
}
// ---------- THE CHARGE (v80): F converts a rally into an attack-move wave ----------
const CHARGE_DIST=85; // how far F hurls the rallied line down the commander's gaze (a dial)
function orderCharge(commander,yaw){
  // v95 PERSONAL WARBANDS: F hurls only the soldiers rallied by THIS commander
  const mil=units.filter(v=>v.alive&&v.team===commander.team&&v.bot&&!v.isKing&&!v.remote&&v.rally&&(v.rallyBy===commander||!v.rallyBy)&&!isWorker(v)); // v134.4
  if(!mil.length)return 0;
  const fx=-Math.sin(yaw),fz=-Math.cos(yaw);
  const sx=commander.root.position.x,sz=commander.root.position.z;
  let tx=sx,tz=sz;
  for(let d=CHARGE_DIST;d>=8;d-=4){ // farthest legal point along the gaze: any walkable ground (fringe and camps included)
    const cx2=sx+fx*d,cz2=sz+fz*d;
    if(walkable(cx2,cz2)){tx=cx2;tz=cz2;break;}
  }
  for(const v of mil)v.chargeTo={x:tx,z:tz};
  // v109 THE VOICES: the warband roars as it storms — a ragged 2-3 voice chorus from the
  // commander's position, host-local + relayed so every client (both teams) hears it coming
  if(typeof Sound!=="undefined"&&Sound.voxChorus)Sound.voxChorus(sx,sz);
  if(typeof NET!=="undefined"&&NET.mode==="host")NET.bcast({t:"snd",k:"__chorus",x:sx,z:sz});
  return mil.length;
}
function engageNearest(u,dt,leash){
  const e=nearestEnemyOf(u,leash||18);
  if(!e)return false;
  const d=dist(u,e);
  const want=u.ranged?u.rng-3:u.rng-0.4;
  if(d>want)moveToward(u,e.root.position.x,e.root.position.z,dt,want);
  else u.facing=Math.atan2(e.root.position.x-u.root.position.x,e.root.position.z-u.root.position.z);
  tryAttack(u);
  return true;
}
// ==================== v113 THE FLANKING LANES ====================
// Every battle used to happen on the King's Road — because the road IS the straight line
// between the two thrones, and every band walked exactly that line (John's field note).
// Each band now holds an APPROACH LANE: a z-corridor it runs down until it's within
// LANE_TURNIN of the objective's x, then it turns in and commits. Armies converge on a base
// from the north field, the south field and the map perimeter instead of one funnel.
// The lanes ROTATE, so a defender can't learn one axis and camp it.
// v132.24 THE LANES BELIEVED IN THE OLD MAP, and the comment that used to stand here said so out
// loud: "MAP.z half-extent is 125, and the creep pockets all sit BEYOND 117 — 88 stays clear of
// them". MAP.z is 152 now, and stage 4 put three creep camps in the OPEN INTERIOR, which is exactly
// the ground a flanking lane is for. A band on lane 88 carries a +-9 jitter from assignLane, so it
// runs 79..97 — and the camp pair at (+-65, 77) has r 11 and an aggro ring reaching z 85.5. Every
// wide band was marching into wolves.
//   0      the King's Road, unchanged
//   +-48   the near flanks. 39..57 with jitter, against an aggro ring reaching 63.5 — 6.5 clear.
//   +-106  the deep perimeter. 97..115, against 85.5 — 11.5 clear. It is 0.70 of the half-extent
//          where 88 was 0.58, so the raid finally uses the depth stage 1 added, and the deep lane
//          runs past the Viking bazaars — a raid on that flank now threatens the new economy.
// LANE_EDGE (MAP.z-10 = 142) still clamps everything short of the border fringe.
const LANE_Z=[0,48,-48,106,-106];
const LANE_TURNIN=62;            // inside this much x of the objective, stop sweeping and drive in
const LANE_EDGE=MAP.z-10;        // never steer into the border fringe
function laneFor(u){
  const bd=u.bandRef;
  if(bd&&bd.laneZ!==undefined)return bd.laneZ;
  return LANE_Z[(u.id||0)%LANE_Z.length]; // loose raiders with no band still fan out, by id
}
function laneTarget(u,tx,tz){ // where this unit should be heading RIGHT NOW to flank (x,z,lane)
  const L=laneFor(u);
  if(!L)return {x:tx,z:tz,lane:false};                       // this band takes the road
  const px=u.root.position.x,pz=u.root.position.z;
  if(Math.abs(px-tx)<LANE_TURNIN)return {x:tx,z:tz,lane:false}; // close enough — turn in
  const zc=Math.max(-LANE_EDGE,Math.min(LANE_EDGE,tz+L));
  if(Math.abs(pz-zc)<10)return {x:tx,z:zc,lane:true};        // ON the lane: run it down
  return {x:px+(tx-px)*0.35,z:zc,lane:true};                 // still cutting out to it
}
function assignLane(D,bd){ // deal the next lane; the two armies start on opposite hands
  D._laneN=(D._laneN||0)+1;
  // v132.24 in step with LANE_Z above — this list is the DEALING ORDER and a stale copy of it deals
  // lanes that no longer exist, which is a silent no-op rather than an error (bd.laneZ would just be
  // a z nobody clears).
  const order=(D.team===BLUE)?[48,-48,106,0,-106]:[-48,48,-106,0,106];
  const base=order[D._laneN%order.length];
  bd.laneZ=base?base+((bd.id%7)-3)*3:0; // jitter the flanks so two bands never stack; the road stays the road
  bd.laneUntil=T+45+(bd.id%5)*9;
}
function raidEnemyBase(u,dt){
  if(!engageNearest(u,dt,17)){
    const etc=TCPOS[1-u.team];
    const _gx=etc[0]+(u.team===BLUE?12:-12);
    const _ap=laneTarget(u,_gx,etc[1]); // v113: swing wide down the lane before turning in
    if(_ap.lane){moveToward(u,_ap.x+u.spread*0.4,_ap.z+u.spread*0.6,dt,6);return;}
    if(moveToward(u,_gx+u.spread*0.4,etc[1]+u.spread,dt,9)){
      let bb=null,bd=1e9;
      for(const bl of buildings){
        if(bl.team===u.team||!bl.alive)continue;
        const d=dist2(u.root.position.x,u.root.position.z,bl.x,bl.z);
        if(d<bd){bd=d;bb=bl;}
      }
      if(bb&&CLS[u.cls].line==="scoutline"){ // trampling scouts hunt FARMS first
        let bf=null,bfd=1e9;
        for(const bl of buildings){
          if(bl.team===u.team||!bl.alive||bl.type!=="farm")continue;
          const d=dist2(u.root.position.x,u.root.position.z,bl.x,bl.z);
          if(d<bfd){bfd=d;bf=bl;}
        }
        if(bf)bb=bf;
      }
      if(bb){moveToward(u,bb.x,bb.z,dt,u.rng+bSurf(bb.def)-0.6);tryAttack(u);}
    }
  }
}
// ==================== WARBANDS: the coordination layer ====================
// Every soldier belongs to a band of ~7 with a mission. The kingsguard always
// exists; the rest patrol, raid the enemy economy, hunt the enemy king, hold
// key ground, or escort the siege train. Threat at the throne recalls them.
let BAND_ID=0;
function bandTargetEcon(team){ // juiciest target: carts and working villagers, then economy buildings
  const et=1-team; let best=null,bd=1e12;
  for(const v of units){
    if(!v.alive||v.team!==et)continue;
    const cart=v.bot&&v.bot.role==="cart";
    const vil=isWorker(v)&&dist2(v.root.position.x,v.root.position.z,TCPOS[et][0],TCPOS[et][1])>26*26; // v134.4: a loaded wain most of all
    if(!cart&&!vil)continue;
    const d=dist2(v.root.position.x,v.root.position.z,TCPOS[team][0],TCPOS[team][1]);
    if(d<bd){bd=d;best=v;}
  }
  if(best)return {unit:best};
  let bb=null; bd=1e12;
  for(const bl of buildings){
    if(!bl.alive||bl.team!==et)continue;
    if(bl.type!=="market"&&bl.type!=="farm"&&bl.type!=="storage_pit")continue;
    const d=dist2(bl.x,bl.z,TCPOS[team][0],TCPOS[team][1]);
    if(d<bd){bd=d;bb=bl;}
  }
  return bb?{bld:bb}:null;
}
// v113: how long a hold band stands its ground, and what counts as "nothing is happening here"
const HOLD_TOUR=45, HOLD_QUIET=18, HOLD_WATCH=48;
// ---- v134.3 THE BAND ECONOMY ----
// BAND_MIN: loose soldiers needed to deal a new mission band. Was an unnamed 5, which was not a
//   considered number — it was the same literal as the "deal in sevens" band size.
// BAND_SEED: …and how few may FOUND a mission nobody is running at all. A fourth body in the patrol
//   is worth less than the first body in the econ raid this marshal's doctrine says it wants.
const BAND_MIN=4, BAND_SEED=3;
// ---- v134.3 THE WILDS ARE WORTH TAKING ----
// CAMP_MIN_MIL: soldiers a team must field before it can spare a band for the woods. Camps cost
//   bodies, and an army that trades its opening force for a chest loses the match it won.
// CAMP_MAX_THREAT: a marshal does not send seven men after treasure while its king is being hunted.
//   Same threat figure the kingsguard sizes itself from.
// CAMP_LOOT_WAIT: the pack dies and the chest appears on that same frame. A band relieved on the
//   instant of the kill walks away from the entire reason it came.
const CAMP_MIN_MIL=16, CAMP_MAX_THREAT=2.5, CAMP_LOOT_WAIT=25;
function bandCampTarget(D,team){
  // the nearest live WILD camp no other band of this army has already claimed. The Viking bay is
  // deliberately not in this pool — see the note at the head of tools/patch-campband-v134.js.
  const taken=new Set();
  for(const b of D.bands)if(b.role==="camp"&&b.camp)taken.add(b.camp);
  let best=null,bd=1e12;
  for(const st of campStates){
    if(st.boss||st.waiting||taken.has(st))continue;
    let alive=0; for(const c of st.creeps)if(c.alive)alive++;
    if(!alive)continue;
    const d=dist2(st.x,st.z,TCPOS[team][0],TCPOS[team][1]);
    if(d<bd){bd=d;best=st;}
  }
  return best;
}
// ---- v134.5 WHAT A SQUARE IS WORTH, IN RESOURCES A SECOND, TO THIS TEAM, RIGHT NOW ----
// BAZ_YIELD_BY_HELD is indexed by the COUNT held: 0/1/2/4 of each of three resources. The value of
// one square is therefore a MARGIN and it moves as the board moves — your third is worth two of
// your first, and one taken from the enemy pays your gain AND their loss on the same march.
// ⚠ IT IS NOT A PROPERTY OF THE BUILDING. The Grand's premium ended at v132.27; what survived it
// was a Grand-first sort in the posting, which spent most of this AI's square-seconds on the
// hardest square of the three (11.4 of plaza, in the middle of the map) for identical pay.
// v134.11 HOW MANY TIMES A SQUARE HAS TO BE TAKEN OFF A DOCTRINE BEFORE IT GUARDS ONE AHEAD OF
// TAKING ONE. Derived from raidAt — the hour a marshal first goes at the enemy, and the plainest
// statement of aggression in PERSONALITIES: rush 80, expand 280, boom 400, turtle 600. The ends are
// read off the table itself so a fifth doctrine cannot silently fall off either end of a pair of
// typed constants. Against a measured 0..3 losses a square that puts turtle at 1 — it guards the
// first time it is thrown off one — boom at 2, expand at 3, and rush at 4, which is to say never:
// a rush would rather take yours than sit on its own, which is the whole of what John asked for.
const _RAID_AT=Object.keys(PERSONALITIES).map(k=>PERSONALITIES[k].raidAt||0);
const _RAID_LO=Math.min.apply(null,_RAID_AT), _RAID_HI=Math.max.apply(null,_RAID_AT);
function doctrineGuardAt(P){
  const r=(P&&P.raidAt)||_RAID_HI;
  const aggr=(_RAID_HI>_RAID_LO)?(_RAID_HI-r)/(_RAID_HI-_RAID_LO):0;
  return 1+Math.round(aggr*3);
}
function bazaarWorth(team,m){
  if(!m)return 0;
  const B=BAZ_YIELD_BY_HELD, cap=B.length-1;
  const at=(n)=>B[Math.max(0,Math.min(n,cap))]||0;
  let mine=0,theirs=0;
  for(const q of neutralMarkets){if(q.owner===team)mine++;else if(q.owner===1-team)theirs++;}
  if(m.owner===team)return (at(mine)-at(mine-1))*3;      // what LOSING this one would cost us
  const gain=at(mine+1)-at(mine);                        // …what taking it would pay
  const deny=(m.owner===1-team)?(at(theirs)-at(theirs-1)):0; // …and what it costs them to lose it
  return (gain+deny)*3;                                  // three resources, so three times over
}
// ---- v134.6 THE SQUARES GET TEETH ----
// BAZ_TOWERS: Guard Towers a team will raise around each square it HOLDS. John asked for 3-4; the
//   map holds 4,200 stone in six piles and a Guard Tower is 250 of it, so 3 each on a swept map is
//   2,250 — 54% of every pile on the board, for one of the two armies. One each is 750, which a
//   team can pay for out of a corner of its mining without giving up its castle. The number is
//   here, alone on a line, when we know what one plays like.
// BAZ_TOWER_GAP / BAZ_TOWER_OUT: where the ring sits, measured from the plaza's edge rather than
//   the square's centre — the Grand's plaza is 11.4 and the pair on the Viking roads are 8.6, so a
//   fixed radius would be inside one and out of range of the others. A Guard Tower reaches 18.
// BAZ_TOWER_STONE: …and it keeps this much stone in the ground for everything else.
// v134.10 TWO TO FOUR, ON THE PRESSURE. John: "they should prioritize towering up at least two to
// four towers to defend their own bazaar depending on … how many times their bazaar has been
// captured during the game. If they are losing their bazaar a lot they should be more inclined to
// protect it." Measured over four seeded 20-minute campaigns, a team loses a given square 0 to 3
// times — the Grand is where the churn is — so the ramp is scaled over that and not over a guess:
// two on a square you hold, and one more for each time you have had it taken off you, to four.
// v134.11 …TO FIVE. John: "I would actually say two to 5 towers." The ceiling was four because the
// ring held four; it holds five at every age the Guard Tower exists in once the Enlightenment
// footprint is measured off the model instead of off its own bounding box (see 00-data.js) and the
// slots are cut for five from the first tower onward. Measured, 40 trials a cell on cleared ground:
// five seated at ages 3, 4 and 5, on the Grand and on both Viking squares, mean 5.0.
const BAZ_TOWERS_MIN=2, BAZ_TOWERS_MAX=5;
// …and the reserve moves with it. 150 was set when the whole feature was one tower a square; a
// garrison that can want twelve would eat the keep behind it, and a CASTLE is 500 stone. Derived
// from the castle rather than typed, so the two cannot drift apart.
const BAZ_TOWER_GAP=3.5, BAZ_TOWER_OUT=7;
const BAZ_TOWER_STONE=(BLD.castle.cost&&BLD.castle.cost.stone)||500;
// kept for the exporter and the older gates: the FLOOR is what "how many towers a square gets"
// meant when it was one number.
const BAZ_TOWERS=BAZ_TOWERS_MIN;
// v134.11 …AND THE DOCTRINE SETS THE FLOOR. John: "how a marshal handles the guard towers at the
// bazaar should be in alignment with the marshal personality. For example the turtle marshal would
// be more inclined to defend their bazaar while the rushing marshal is going to be more inclined to
// capture the enemies bazaar vs defending their own."
// THE FLOOR IS P.towers, WHICH THE TABLE ALREADY SAYS — rush 2, boom 2, expand 3, turtle 4. A second
// per-personality number would be a copy of the first that nothing keeps in step; this is the same
// statement ("how tower-minded is this doctrine") spent on a different budget, and the budgets have
// been separate since v134.9, when countScreenTowers stopped counting bazaar towers against the
// town's screen. So a turtle opens with four round every square it holds and reaches five the first
// time one is taken off it; a rush opens with two and only reaches five if it is losing badly.
function bazTowerWant(team,m){ // how big a garrison this square has earned
  const P=(typeof directors!=="undefined"&&directors[team]&&PERSONALITIES[directors[team].pers])||null;
  const floor=Math.max(BAZ_TOWERS_MIN,Math.min(BAZ_TOWERS_MAX,(P&&P.towers)||BAZ_TOWERS_MIN));
  const lost=(m&&m.lost&&m.lost[team])||0;
  return Math.min(BAZ_TOWERS_MAX,floor+lost);
}

function bazTowerSpot(team,m){
  // a legal plot in the ring, preferring the side this throne is on: the villagers who build it
  // walk from home, and a tower on the far face is a two-minute march through the enemy's half.
  const tc=TCPOS[team], plaza=(m.plaza||8.6);
  // AND THE OUTER EDGE IS THE TOWER'S OWN REACH, not a fixed distance from the plaza. The Grand's
  // plaza is 11.4 against 8.6 for the pair on the Viking roads, so plaza+3.5+7 puts a tower 21.9
  // out — past the 18 it can shoot, guarding the square by standing near it and watching. Caught by
  // the gate the moment it was written: "nearest 12.1, furthest 21.7 ... and a range of 18".
  const inner=plaza+BAZ_TOWER_GAP;
  const outer=Math.max(inner+1,Math.min(inner+BAZ_TOWER_OUT,(BLD.tower.atk.rng||18)-1.5));
  // v134.11 THE RING IS A LATTICE, AND IT IS LAID OUT FOR THE MOST THE SQUARE COULD EVER HOLD.
  // v134.10 swept the ring and put each new tower in the middle of the widest gap, which is right
  // for the tower being placed and wrong for the one after it: two towers seated opposite each
  // other can NEVER grow into five, because each 180-degree arc then takes exactly one more. That
  // is why the sweep topped out at four however the radius was sampled, and it is arithmetic rather
  // than luck: five towers want 72 degrees between neighbours and a 180-degree arc holds one at
  // 71.2.
  // So the slots are cut once, for BAZ_TOWERS_MAX, and the garrison size decides how many are
  // FILLED — never where they are. A square that earns its fifth tower in the twentieth minute puts
  // it in a slot that was left standing empty for it in the third.
  // THE RADIUS IS THE ONE THE SPACING NEEDS AT THAT SLOT COUNT, AT THE LARGEST THIS BUILDING EVER
  // GETS. A lattice laid at the Classical footprint (6.30, so 18.6 between centres) stops accepting
  // towers the moment the town reaches Enlightenment, where the bastion wants 19.2 — so the ring
  // would quietly shrink by one at the age it is needed most. Reading every age costs one loop at
  // placement time and makes the ring age-proof by construction.
  let _w=0;
  for(let a=(BLD.tower.age||0);a<=5;a++)
    _w=Math.max(_w,2*Math.max(BLD.tower.fxA[a],BLD.tower.fzA[a]));
  // validFor's own arithmetic for a tower against a tower (06-input.js _gapFor): the two footprints
  // plus 0.75 of the smaller width, floored at 2.2 and capped at 6.0. Restated rather than shared
  // because _gapFor is a closure inside validFor — so the gate PROBES validFor for the real refusal
  // distance instead of replaying this sum, which is the only way the two can be held together.
  const _need=_w+Math.max(2.2,Math.min(6.0,0.75*_w));
  const _rLat=Math.max(inner,Math.min(outer,_need/(2*Math.sin(Math.PI/BAZ_TOWERS_MAX))));
  const _step=Math.PI*2/BAZ_TOWERS_MAX;
  const held=[];
  for(const b of buildings)
    if(b.alive&&b.team===team&&b.type==="tower"&&dist2(b.x,b.z,m.x,m.z)<Math.pow(outer+3,2))
      held.push(Math.atan2(b.z-m.z,b.x-m.x));
  // the pattern is anchored on the FIRST tower that stood, so it never shifts under itself; with an
  // empty ring it is anchored on the bearing home, which is where the first one wanted to be anyway.
  const _anchor=held.length?held[0]:Math.atan2(tc[1]-m.z,tc[0]-m.x);
  // how far a candidate may wander off its slot and still leave both neighbours their room. At the
  // Enlightenment footprint this is nearly zero and the bearings are held exact; at the Medieval
  // drum it is about seventeen degrees, and the ring looks placed rather than stamped.
  const _slack=Math.max(0,_step-2*Math.asin(Math.min(1,_need/(2*_rLat))));
  const _jit=_slack*0.8;
  // AND THE RADIUS ONLY EVER WANDERS OUTWARD. _rLat is the radius at which the slot count EXACTLY
  // fits, so a candidate half a unit inside it has a shorter chord than the spacing needs and the
  // last tower is refused. Measured: a symmetric wobble of +-0.085 cost the fifth tower at age 5 on
  // both squares, and the same sampler biased outward seats five at every age.
  const _rj=Math.max(0,outer-_rLat);
  let best=null,bs=-1e12, near=null,nd=1e12;
  for(let i=0;i<36;i++){
    const a=_anchor+(i%BAZ_TOWERS_MAX)*_step+(Math.random()-0.5)*_jit;
    const r=Math.max(inner,Math.min(outer,_rLat+Math.random()*_rj));
    const x=m.x+Math.cos(a)*r, z=m.z+Math.sin(a)*r;
    if(Math.abs(x)>MAP.x-6||Math.abs(z)>MAP.z-6)continue;
    if(!validFor("tower",x,z,team))continue;
    const d=dist2(x,z,tc[0],tc[1]);
    if(d<nd){nd=d;near={x,z};}                       // …the old rule, kept as the fallback
    // the emptiest slot wins. Home is the tie-break, weighted so it decides between equals and
    // never overrides the ring: a throne is ~200 units away, so 0.0008 rad a unit is about nine
    // degrees of pull, against slots that stand 72 apart.
    let sep=Math.PI;
    for(const t of held){
      const g=Math.abs(((a-t+Math.PI*3)%(Math.PI*2))-Math.PI);
      if(g<sep)sep=g;
    }
    const score=sep-Math.sqrt(d)*0.0008;
    if(score>bs){bs=score;best={x,z};}
  }
  // …and if the ring is so hemmed in that nothing legal was found at all, the old rule still
  // answers: a marshal that builds nothing because it cannot build TIDILY is worse than a huddle.
  return best||near;
}
function bandHoldPoint(team,idx){ // the square that pays most, held or not, then the road
  // v134.3 THE CASTLE USED TO COME FIRST, AND EVERY DOCTRINE BUILDS A CASTLE. From the moment the
  // first one finished, no band was ever posted to a bazaar again — which quietly retired the whole
  // v132.26 change below at about minute ten, and left squares paying 4 a second standing neutral
  // for a whole match (measured: seed 11, twenty minutes, one square never claimed by anybody).
  // Standing in your own courtyard is not worth more than the thing that pays. Once every square IS
  // yours the castle posting is right again, and that is exactly what this falls through to.
  // v134.5 THE CASTLE POSTING IS GONE. v134.3 put the castle back for a swept map — "once every
  // square is yours the castle posting is right again" — and that was wrong twice over: a swept map
  // pays 12 a second, the largest income in the game, and the instant it is swept is the instant it
  // is worth guarding. Measured on v134.4: blue took ten squares across three campaigns and lost
  // five of them, because the doctrine asked for a hold band per square STILL UP FOR GRABS, so a
  // team that held them all asked for none and the last band went home to stand in its courtyard.
  // A castle guards itself; it has walls, towers and a garrison. A bazaar has a plinth.
  // v132.26 A BAZAAR IS WORTH TAKING NOW, AND THIS USED TO STAND THREE UNITS OUTSIDE IT. The old
  // line dealt bazaars round-robin by band index and posted the band at (m.x+3, m.z+3) — outside
  // the plaza on the small ones, so a hold band would have stood beside a capturable objective for
  // the whole match without ever capturing it. It stands ON the square now, and it prefers a
  // square this team does not already hold: the Grand first, because it pays three times either of
  // the others, then whichever of the rest is nearest this throne.
  if(neutralMarkets.length){
    // v134.5 RANKED BY WHAT IT PAYS, then by which one this throne can realistically keep. The old
    // sort was (b.grand?1:0)-(a.grand?1:0) || nearest — Grand first, and the Grand has paid exactly
    // what the other two pay since v132.27. On the three seeds measured it took 546 of blue's 921
    // square-seconds, 971 of 1756 and 888 of 2925: most of this army's holding, spent on the one
    // square hardest to hold, for no premium at all.
    const _rank=(a,b)=>bazaarWorth(team,b)-bazaarWorth(team,a)||
      dist2(a.x,a.z,TCPOS[team][0],TCPOS[team][1])-dist2(b.x,b.z,TCPOS[team][0],TCPOS[team][1]);
    // …and the ones we do NOT hold are spoken for first: a band that takes a square earns more than
    // a band that stands on one we already have. Guarding is what the spare bands are for.
    // v134.11 …EXCEPT A SQUARE THIS DOCTRINE HAS ALREADY BEEN THROWN OFF. John: "the turtle marshal
    // would be more inclined to defend their bazaar while the rushing marshal is going to be more
    // inclined to capture the enemies bazaar vs defending their own." THIS LINE IS WHERE THAT LIVES
    // and nothing was reading it: take-before-guard was unconditional, for all four doctrines, so a
    // turtle sent its first bands at the enemy's squares exactly like a rush. bazaarWorth could not
    // have carried it either — it only sorts WITHIN each group, and the groups are hard-ordered
    // here, above it.
    // The bar is LOSSES, not taste, so a doctrine nobody is pressing still goes and takes: sitting
    // on a square that pays nothing extra while the enemy sweeps the board is not defence.
    const _guardAt=doctrineGuardAt(directors[team]&&PERSONALITIES[directors[team].pers]);
    const _pressed=(q)=>(((q.lost&&q.lost[team])||0)>=_guardAt);
    const want=neutralMarkets.filter(m=>m.owner!==team).sort(_rank);
    const mine=neutralMarkets.filter(m=>m.owner===team).sort(_rank);
    const _bled=mine.filter(_pressed), _calm=mine.filter(q=>!_pressed(q));
    const order=_bled.concat(want,_calm);
    const m=order[idx%order.length];
    return {x:m.x,z:m.z,why:m.owner===team?"guard":"bazaar",baz:m};
  }
  const tc=TCPOS[team],et=TCPOS[1-team];
  return {x:tc[0]+(et[0]-tc[0])*0.35,z:tc[1]+(et[1]-tc[1])*0.35,why:"road"};
}
function manageBands(D){
  const team=D.team;
  D.bands=D.bands||[];
  for(const bd of D.bands){ // prune the dead, the possessed, the re-classed
    const _keep=bd.members.filter(v=>v.alive&&!v.remote&&v.team===team&&v.bot&&!v.isKing&&
      !isWorker(v)&&CLS[v.cls].line!=="healer"&&v.bandRef===bd); // v134.4: isWorker covers the cart role AND the ox
    // v134.9 …AND LEAVING A BAND'S ROSTER RELEASES THE SOLDIER. This filtered and stopped. A body
    // dropped here kept bandRef pointing at a band it was no longer in, and the roster below is
    // built from `!v.bandRef || !D.bands.includes(v.bandRef)` — so a pointer at a live band it
    // is not a member of makes a soldier INVISIBLE to every deal for the rest of the match.
    // Measured on SMOKE_SEED=777: BLUE ended with 16 of 23 soldiers holding a bandRef to a camp
    // band that listed six of them, and a kingsguard that listed none. The death/respawn round trip
    // is the common path (see respawnUnit) but the re-class and the wain reach it without dying.
    for(const v of bd.members)if(_keep.indexOf(v)<0&&v.bandRef===bd)v.bandRef=null;
    bd.members=_keep;
  }
  D.bands=D.bands.filter(bd=>bd.members.length>0||bd.role==="kingsguard");
  const roster=[];
  for(const v of units){
    if(!v.alive||v.team!==team||!v.bot||v.isKing||v.remote)continue;
    if(isWorker(v)||CLS[v.cls].line==="healer")continue; // v134.4: no wain is dealt into a band
    if(!v.bandRef||!D.bands.includes(v.bandRef))roster.push(v);
  }
  // --- threat at the throne ---
  const k=kings[team]; let threat=0;
  for(const e of units){
    if(!e.alive||e.team===team||e.cls==="villager")continue;
    const d=Math.sqrt(dist2(e.root.position.x,e.root.position.z,k.root.position.x,k.root.position.z));
    if(d<42)threat+=(42-d)/42;
  }
  threat+=(1-k.hp/Math.max(1,k.maxHp))*3;
  D.threat=threat;
  // --- the kingsguard fills first and grows with the danger ---
  let kg=D.bands.find(b=>b.role==="kingsguard");
  if(!kg){kg={id:BAND_ID++,role:"kingsguard",members:[]};D.bands.push(kg);}
  const PB=PERSONALITIES[D.pers]||PERSONALITIES.expand; // v94: the doctrine staffs the guard
  const kgNeed=Math.min(14,(PB.kgBase||6)+Math.floor(threat*1.5));
  while(kg.members.length<kgNeed&&roster.length){const v=roster.pop();v.bandRef=kg;kg.members.push(v);}
  while(kg.members.length>kgNeed){ // peace releases the surplus to the war effort
    const v=kg.members.pop(); v.bandRef=null; roster.push(v);
  }
  // --- the siege train: engines plus an escort ---
  const looseSiege=roster.filter(v=>isSiege(v.cls));
  if(looseSiege.length){
    let st=D.bands.find(b=>b.role==="siege");
    if(!st){st={id:BAND_ID++,role:"siege",members:[]};D.bands.push(st);}
    for(const v of looseSiege){v.bandRef=st;st.members.push(v);roster.splice(roster.indexOf(v),1);}
    let esc=st.members.filter(v=>!isSiege(v.cls)).length;
    while(esc<4&&roster.length){const v=roster.shift();v.bandRef=st;st.members.push(v);esc++;}
  }
  // --- deal the rest into mission bands of ~7, line-sorted for mixed company ---
  // v134.3 ⚠ THE DOCTRINE IS READ EVEN WHEN THERE IS NOBODY LEFT TO DEAL. All of this used to sit
  // inside the roster.length>=5 block, which was harmless while its only consumer was the deal loop
  // in the same block — and quietly fatal to the founding pass below, whose entire purpose is to
  // fire on a TRICKLE of three. With the wanted-role map undefined whenever the loose pool is short
  // of a full band, three reinforcements fell straight past the pass into the straggler loop, and
  // the fix was a no-op in precisely the case its own comment describes.
  // The order of this list is a PRIORITY as well as a set: the founding pass opens the first role
  // nobody is running. A square pays 1, 2 or 4 a second of three resources; a patrol loop around
  // one's own town pays nothing. Squares first, then the enemy's supply lines, then the patrol.
  const wantRoles=["hold","econ","patrol"];
  for(let i=0;i<(PB.econHunters||0);i++)wantRoles.push("econ"); // rush lives on dead supply chains
  if(roster.length>=20||D.raidUntil||((PB.assassins||0)&&roster.length>=10))wantRoles.push("assassin");
  // v134.3 ONE HOLD BAND PER SQUARE STILL UP FOR GRABS. Three bazaars pay 1, 2 and 4 a second of
  // food AND gold AND wood by count held; an army that fields one hold band can take one square.
  {const _nm=(typeof neutralMarkets!=="undefined")?neutralMarkets:[];
   const _free=_nm.filter(m=>m.owner!==team).length, _held=_nm.filter(m=>m.owner===team).length;
   for(let i=1;i<_free&&wantRoles.length<9;i++)wantRoles.push("hold");
   // v134.5 …AND ONE MORE WHEN THE NEXT SQUARE COMPLETES THE SWEEP. The table doubles at three
   // (1/2/4), so the last square is worth two of the first — the one moment in this game where the
   // marginal objective is worth MORE than the one before it, and the AI has been treating them
   // all alike. Measured: the two armies together collected a mean of 1.84, 2.44 and 3.26 of a
   // possible 4 over three campaigns, so the doubling was very nearly never collected by anybody.
   if(_free>0&&_held===_nm.length-1&&wantRoles.length<9)wantRoles.push("hold");
   // v134.5 …AND ONE TO GUARD WHAT IS ALREADY HELD. This list asked only for squares still up for
   // grabs, so a team that held some asked for nothing to keep them and lost a third to a half of
   // everything it took (10 taken, 5 lost, blue, three seeds).
   if(_held>0&&wantRoles.length<9)wantRoles.push("hold");}
  // v134.3 …AND ONE BAND FOR THE WILDS, once there is an army to spare it from and the throne is
  // quiet. Nine camps, a 300-resource chest on a 180-second cycle, and since v134.2 a pack is
  // worth levels to whoever breaks it — and until now every one of them was a human prize by
  // default rather than by contest.
  // ⚠ BAND_MIN loose soldiers, not eight. The first cut asked for eight and measured ZERO camp
  // bands across two twenty-minute campaigns, because by the time bands are dealt the loose pool is
  // rarely that deep. This is also the one mission a trickle may NOT found — camps cost bodies, and
  // three soldiers walking into a pack of five is a donation.
  if(roster.length>=BAND_MIN&&threat<CAMP_MAX_THREAT&&
     units.filter(v=>v.alive&&v.team===team&&v.bot&&!v.isKing&&!isWorker(v)).length>=CAMP_MIN_MIL&& // v134.4
     bandCampTarget(D,team))wantRoles.push("camp");
  // v134.3 …AND THE PICKER CAN COUNT NOW. It used to be:
  //     let role=wantRoles[0],least=1e9;
  //     for(const r of wantRoles){const n=bands(r).length; if(n<least){least=n;role=r;}}
  // — which reads the list as a SET. A repeat computes the same n as its first occurrence and
  // n<least is false, so no repeat could ever win, so PERSONALITIES.rush.econHunters ("rush lives
  // on dead supply chains", v94) has done precisely nothing since the day it shipped and rush has
  // raided supply lines exactly as hard as turtle. Weight = how many times the role is asked for;
  // pick the biggest DEFICIT. ⚠ This is a real balance change for rush and expand.
  const _want={};
  for(const r of wantRoles)_want[r]=(_want[r]||0)+1;
  if(roster.length>=BAND_MIN){
    roster.sort((a,b)=>CLS[a.cls].line<CLS[b.cls].line?-1:1);
    while(roster.length>=BAND_MIN){
      // the mission we are furthest SHORT on, counting how many of each the doctrine asked for
      let role=wantRoles[0],worst=-1e9;
      for(const r in _want){
        const def=_want[r]-D.bands.filter(b=>b.role===r).length;
        if(def>worst){worst=def;role=r;}
      }
      const size=Math.min(roster.length,7);
      let bd=D.bands.find(b=>b.role===role&&b.members.length<5);
      if(!bd){bd={id:BAND_ID++,role,members:[]};D.bands.push(bd);}
      for(let i=0;i<size;i++){const v=(i%2?roster.pop():roster.shift());v.bandRef=bd;bd.members.push(v);}
    }
  }
  // v134.3 …BUT FIRST, A MISSION NOBODY IS RUNNING GETS OPENED. The loop below used to hand every
  // loose body to an existing band, up to eight, which meant REINFORCEMENT ALWAYS BEAT FORMATION:
  // whatever bands existed after the first few think-clocks were the only bands the army ever had,
  // and a twenty-minute match ended with one mission band or none (measured, both teams, several
  // seeds). Every doctrine knob in PERSONALITIES was describing an army that never got built.
  // BAND_SEED, not BAND_MIN: three is fewer than a band should be, and a great deal more than the
  // nothing that was previously in the woods, on the squares, and on the enemy's supply lines.
  while(roster.length>=BAND_SEED){
    let missing=null;
    for(const r in _want)if(!D.bands.some(b=>b.role===r)){missing=r;break;}
    if(!missing)break;
    const bd={id:BAND_ID++,role:missing,members:[]};
    D.bands.push(bd);
    const n=Math.min(roster.length,7);
    for(let i=0;i<n;i++){const v=(i%2?roster.pop():roster.shift());v.bandRef=bd;bd.members.push(v);}
  }
  for(const v of roster){ // stragglers reinforce the weakest mission band, not the throne
    let bd=null,bs=99;
    for(const b of D.bands)
      if(b.role!=="kingsguard"&&b.role!=="siege"&&b.members.length<8&&b.members.length<bs){bs=b.members.length;bd=b;}
    if(!bd)bd=kg;
    v.bandRef=bd; bd.members.push(v);
  }
  // --- mission control ---
  D.rolesSeen=D.rolesSeen||{};
  const side=team===BLUE?1:-1; let hi=0;
  for(const bd of D.bands){
    D.rolesSeen[bd.role]=1;
    bd.defend=threat>4.5; // the palace burns: everyone home
    if(bd.laneZ===undefined||T>(bd.laneUntil||0))assignLane(D,bd); // v113: fresh approach lane, rotated
    if(bd.role==="econ"&&(!bd.target||(bd.target.unit&&!bd.target.unit.alive)||(bd.target.bld&&!bd.target.bld.alive)))
      bd.target=bandTargetEcon(team);
    if(bd.role==="hold"){
      // v113 A POSTING IS NOT A CAREER. A hold band used to stand on its bazaar for the rest
      // of the match doing nothing (John: "AI units huddled up around the nearest bazaar").
      // It now serves a TOUR: once the ground has been quiet for HOLD_QUIET seconds and the
      // tour has run out, the band is relieved and takes whatever mission the army is
      // shortest on. Contact resets the clock, so a bazaar actually under threat is still held.
      bd.point=bandHoldPoint(team,hi++);
      if(bd.holdUntil===undefined){bd.holdUntil=T+HOLD_TOUR;bd.lastContact=T;}
      let cx=0,cz=0,cn=0;
      for(const v of bd.members){cx+=v.root.position.x;cz+=v.root.position.z;cn++;}
      if(cn){
        cx/=cn;cz/=cn;
        for(const e of units){ // only the ENEMY ARMY holds a posting — a nearby wild camp is
          // scenery, and letting creeps reset the clock is exactly how a band ends up parked forever
          if(!e.alive||e.team===team||e.team===NEUTRAL||isWorker(e))continue; // v134.4: a passing cart is not contact
          if(dist2(e.root.position.x,e.root.position.z,cx,cz)<HOLD_WATCH*HOLD_WATCH){bd.lastContact=T;break;}
        }
      }
      // v132.26 …AND A BAND MID-CAPTURE IS NOT RELIEVED. The tour clock exists so a band does not
      // stand on quiet ground for ever; a bazaar that is 60% taken is not quiet ground, and being
      // marched off it at 59% would waste the whole tour and hand the square back.
      const _bz=bd.point&&bd.point.baz;
      const _taking=_bz&&(_bz.owner!==team)&&(_bz.capTeam===team||_bz.cap>0.02);
      // v134.5 …AND THE LAST GUARD ON A SQUARE WE HOLD DOES NOT WALK AWAY FROM IT. The tour clock
      // exists so a band does not stand on quiet ground for ever, and quiet ground is exactly what
      // an unguarded bazaar looks like right up until somebody strolls onto it. One band may be
      // pinned this way, never more: with a second hold band on the board the tour runs as usual.
      const _guard=_bz&&_bz.owner===team&&D.bands.filter(b=>b.role==="hold").length<=1;
      if(T>bd.holdUntil&&T-(bd.lastContact||0)>HOLD_QUIET&&!_taking&&!_guard){ // relieved — march on
        // v134.3 …AND THE WILDS ARE ONE OF THE MISSIONS IT CAN TAKE. Measured: a marshal forms one
        // or two mission bands in a whole twenty-minute campaign — the kingsguard absorbs the army
        // (kgBase plus threat, up to 14) and the loose pool reaches five only five or six times a
        // match. So a NEW role competing for that slot loses to hold every time and never runs at
        // all. A band with nothing left to hold is exactly the band that should be in the woods,
        // and reusing it costs no slot.
        // ⚠ AND IT HAS TO BE AN EXPLICIT PREFERENCE, not a tie-break. The loop below takes the
        // FIRST role with the lowest count, so with econ at 0 and camp at 0 econ wins every time and
        // camp never runs — the same "first wins ties" shape as the wantRoles bug this version
        // already fixed. A band that has just finished taking a square, with a live pack on the map
        // and nobody in the woods, goes to the woods.
        let role="econ",least=1e9;
        if(bandCampTarget(D,team)&&!D.bands.some(b=>b.role==="camp")){
          bd.role="camp"; bd.point=null; bd.camp=null; bd.lootUntil=0; assignLane(D,bd);
          continue;
        }
        for(const r of ["econ","patrol","assassin"]){
          const n=D.bands.filter(b=>b.role===r).length;
          if(n<least){least=n;role=r;}
        }
        bd.role=role; bd.point=null; bd.wps=null; bd.holdUntil=undefined; bd.target=null;
        assignLane(D,bd); // and it takes a NEW axis on the way out
      }
    }
    if(bd.role==="camp"){
      // keep a live target; a pack that was wiped by somebody else is not worth walking to
      if(bd.camp){
        let alive=0; for(const c of bd.camp.creeps)if(c.alive)alive++;
        if(!alive&&!bd.camp.chest)bd.lootUntil=bd.lootUntil||T+CAMP_LOOT_WAIT;
        if(bd.camp.waiting&&!bd.camp.chest&&T>(bd.lootUntil||0)){bd.camp=null;bd.lootUntil=0;}
      }
      if(!bd.camp){
        bd.camp=bandCampTarget(D,team);
        bd.lootUntil=0;
        if(!bd.camp){ // the wilds are quiet: back to the war, the way a relieved hold band goes
          let role="econ",least=1e9;
          for(const r of ["econ","patrol","assassin"]){
            const n=D.bands.filter(b=>b.role===r).length;
            if(n<least){least=n;role=r;}
          }
          bd.role=role; bd.point=null; bd.target=null; assignLane(D,bd);
        }
      }
      // the throne outranks the treasure, always — bd.defend is already set above from threat
    }
    if(bd.role==="patrol"){
      // v134.5 THE PATROL SWEEPS THE SQUARES TOO. These four waypoints are a box within 26 of the
      // town centre — a loop around ground that already has a Town Center, a kingsguard and every
      // building this team owns standing on it. Meanwhile the thing that pays 12 a second sits out
      // on the road with at most one band on it. A patrol is the cheapest defence in the game and
      // it was walking circles in the safest place on the map.
      // ⚠ AND THE LIST IS REBUILT WHEN THE BOARD CHANGES. bd.wps was set once and kept for the
      // life of the band, so a square taken after the band formed would never have been walked.
      const _hk=(typeof neutralMarkets!=="undefined")?neutralMarkets.map(m=>m.owner).join(""):"";
      if(!bd.wps||bd.wpKey!==_hk){
        const tc=TCPOS[team];
        // v134.9 OUTSIDE THE CORN. These four were (15,11) (22,16) (4,-24) (26,-6) from the
        // throne — the furthest 27.20 out against a TC_RING of 30 — so the whole loop ran INSIDE
        // the farm ring, through this team's own fields, past its own kingsguard. The offsets
        // predate the ring: v134.1 pushed every other sampler out with it and missed this one,
        // exactly as it found the curtain's middle segment sitting on the ring. Derived from
        // TC_RING now, so it moves when the ring does, and shortened on the rear leg (0.85) so the
        // long side of the loop is the side an attacker crosses. ⚠ 0.85, not 0.5: the first cut
        // weighted it 2:1 and put the rear waypoint at 18 from the throne — back inside the corn,
        // which is the very thing this change is about. The gate caught it.
        const _pr=TC_RING+6;
        bd.wps=[{x:tc[0]+side*_pr,      z:tc[1]},
                {x:tc[0]+side*_pr*0.7,  z:tc[1]+_pr*0.7},
                {x:tc[0]-side*_pr*0.85, z:tc[1]},
                {x:tc[0]+side*_pr*0.7,  z:tc[1]-_pr*0.7}];
        if(typeof neutralMarkets!=="undefined")
          for(const m of neutralMarkets)if(m.owner===team)bd.wps.push({x:m.x,z:m.z});
        bd.wpKey=_hk;
        bd.wi=0;
      }
      const wp=bd.wps[bd.wi]; let near=0;
      for(const v of bd.members)if(dist2(v.root.position.x,v.root.position.z,wp.x,wp.z)<10*10)near++;
      if(near>=bd.members.length*0.6)bd.wi=(bd.wi+1)%bd.wps.length;
    }
  }
  // --- a struck building calls the nearest patrol or hold band ---
  if(T-(D.lastAid||0)>6){
    for(const bl of buildings){
      if(bl.team!==team||!bl.alive||!bl.lastHit||T-bl.lastHit>5)continue;
      let best=null,bdd=1e12;
      for(const bd of D.bands){
        if(bd.role!=="patrol"&&bd.role!=="hold")continue;
        for(const v of bd.members){const d=dist2(v.root.position.x,v.root.position.z,bl.x,bl.z);if(d<bdd){bdd=d;best=bd;}}
      }
      if(best){best.aid={x:bl.x,z:bl.z,r:bSurf(bl.def),until:T+14};D.lastAid=T;}
      break;
    }
  }
  // --- a worker under attack screams: the fastest sabres ride to the rescue ---
  if(D.distress&&T<D.distress.until&&T-(D.lastRescue||0)>8){
    let best=null,bs=-1e15;
    for(const bd of D.bands){
      if(bd.role==="kingsguard"||bd.role==="siege")continue;
      let mounted=0,cx=0,cz=0,n=0;
      for(const v of bd.members){if(CLS[v.cls].mounted)mounted++;cx+=v.root.position.x;cz+=v.root.position.z;n++;}
      if(!n)continue;
      const d=Math.sqrt(dist2(cx/n,cz/n,D.distress.x,D.distress.z));
      const score=mounted*400-d; // cavalry first, then whoever is closest
      if(score>bs){bs=score;best=bd;}
    }
    if(best){
      best.aid={x:D.distress.x,z:D.distress.z,until:T+14};
      D.lastRescue=T; D.distress=null;
      if(team===RED)msg("Red riders wheel toward their workers…","gold");
      else msg("⚑ A band rides to defend your villagers!","blue");
    }
  }
  // --- overwhelmed at the Town Center: the villagers themselves take up arms ---
  const tcL=teamTC(team);
  if(tcL){
    let foes=0,defs=0;
    for(const e of units){
      if(!e.alive||isWorker(e)||e.isKing)continue; // v134.4: a stray cart does not raise the levy
      if(dist2(e.root.position.x,e.root.position.z,tcL.x,tcL.z)<34*34){
        if(e.team!==team)foes++; else defs++;
      }
    }
    if(foes>=3&&foes>defs+2&&T-(D.lastLevy||0)>10){
      const levyCls=lineUnitFor("melee",team)||"clubman";
      let levied=0, already=units.filter(v=>v.alive&&v.team===team&&v._levy).length;
      for(const v of units){
        if(already+levied>=6)break; // a militia, not the whole workforce
        if(!v.alive||v.team!==team||v.cls!=="villager"||!v.bot||v.remote||v.isPlayer||v.isKing)continue;
        if(dist2(v.root.position.x,v.root.position.z,tcL.x,tcL.z)>45*45)continue;
        setClass(v,levyCls); v._levy=true; v._levyClear=T; levied++;
      }
      if(levied>0){
        D.lastLevy=T;
        msg(team===BLUE?"⚔ Your villagers take up arms to defend the Town Center!"
                       :"The Red villagers arm themselves to hold their Town Center!",
            team===BLUE?"blue":"red");
      }
    }
    // stand down: ten quiet seconds and the militia returns to the fields
    for(const v of units){
      if(!v._levy||!v.alive||v.team!==team)continue;
      if(foes>0)v._levyClear=T;
      else if(T-(v._levyClear||0)>10){
        setClass(v,"villager"); v._levy=false; v.bandRef=null;
      }
    }
  }
}
function nearestDropoff(u){ // the closest place to bank a load
  const px=u.root.position.x,pz=u.root.position.z;
  let best=teamTC(u.team), bd=best?dist2(px,pz,best.x,best.z):1e12;
  for(const b of buildings){
    if(b.team!==u.team||!b.alive||!b.built)continue;
    if(b.type!=="storage_pit"&&b.type!=="castle")continue;
    const d=dist2(px,pz,b.x,b.z);
    if(d<bd){bd=d;best=b;}
  }
  return best;
}
function nearestNeutral(x,z){
  let best=null,bd=1e12;
  for(const m of neutralMarkets){const d=dist2(x,z,m.x,m.z);if(d<bd){bd=d;best=m;}}
  return best;
}
function updateBot(u,dt){
  if(u.remote)return; // a human wears this body — driveRemote owns it
  const b=u.bot;
  if(b.role==="creep")return updateCreep(u,dt); // the wilds answer to no director
  // TRADE CARTS: out to the bazaar, trade, haul the gold home — rain or raiders
  if(b.role==="cart"){
    const home=b.home;
    if(!home||!home.alive)return; // market burned: the cart is stranded
    if(!u.tradeTarget){u.tradeTarget=nearestNeutral(home.x,home.z);u.tradePhase="out";}
    if(u.tradePhase==="out"){
      if(moveToward(u,u.tradeTarget.x,u.tradeTarget.z,dt,3.2)){u.tradePhase="trading";u.tradeT=2;}
    }else if(u.tradePhase==="trading"){
      u.tradeT-=dt;
      if(u.tradeT<=0){u.tradePhase="back"; // v104: cart finished loading at the bazaar
        if(typeof Sound!=="undefined"&&u.team===MYTEAM)Sound.play("bazaarload",{x:u.root.position.x,z:u.root.position.z});
        if(typeof NET!=="undefined"&&NET.mode==="host"&&typeof teamHasHuman==="function"&&teamHasHuman(u.team))NET.bcast({t:"snd",k:"bazaarload",team:u.team,x:u.root.position.x,z:u.root.position.z});}
    }else{
      // v134.4 …AND SO DID THE TRADE CART, which is the worst of the three: the aim point was a
      // fixed EAST-of-the-market spot at bSurf+2 = 14.7 off centre against a stop of 11.60. Near
      // side 6.20, far side 23.20. A cart whose bazaar lies west of its market could never deliver
      // — it arrived, failed the test, and orbited its own market for the rest of the match with
      // the gold still on board. v104 shipped it and nothing has ever measured it.
      const _cdx=u.root.position.x-home.x,_cdz=u.root.position.z-home.z,_cl=Math.hypot(_cdx,_cdz)||1;
      if(moveToward(u,home.x+_cdx/_cl*(bSurf(home.def)+1.2),home.z+_cdz/_cl*(bSurf(home.def)+1.2),dt,1.6)){
        const d=Math.hypot(home.x-u.tradeTarget.x,home.z-u.tradeTarget.z);
        const g=tradeGold(d);
        stock[u.team].gold+=g;
        if(typeof Sound!=="undefined"&&u.team===MYTEAM)Sound.play("tradepay",{x:u.root.position.x,z:u.root.position.z}); // v104: cart delivers gold
        if(typeof NET!=="undefined"&&NET.mode==="host"&&typeof teamHasHuman==="function"&&teamHasHuman(u.team))NET.bcast({t:"snd",k:"tradepay",team:u.team,x:u.root.position.x,z:u.root.position.z});
        if(u.team===BLUE){updateResHud();msg("Trade cart returned: +"+g+" gold.","blue");}
        u.tradePhase="out";u.tradeTarget=nearestNeutral(home.x,home.z);
      }
    }
    return;
  }
  // KING: hover the throne, flee attackers, swing when cornered
  if(b.role==="king"){
    const tc=teamTC(u.team);
    const hx=tc?tc.x:TCPOS[u.team][0],hz=tc?tc.z:TCPOS[u.team][1];
    const e=nearestEnemyOf(u,16);
    if(e){
      if(dist(u,e)<3)tryAttack(u);
      const fx=hx+(hx-e.root.position.x)*0.35,fz=hz+(hz-e.root.position.z)*0.35;
      moveToward(u,Math.max(-MAP.x,Math.min(MAP.x,fx)),Math.max(-MAP.z,Math.min(MAP.z,fz)),dt,1);
    }else{
      if(!b.wt||T>b.wt){b.wt=T+3+Math.random()*3;b.wx=hx+(Math.random()-0.5)*10;b.wz=hz+(Math.random()-0.5)*10;}
      moveToward(u,b.wx,b.wz,dt,0.8);
    }
    return;
  }
  // CITIZENS
  // v134.4: …and the ox works this branch too. Without it a yoked ox falls through to the MILITARY
  // branch below — 220 hp of timber wain trying to find something to hit.
  if(isWorker(u)){
    const threat=nearestEnemyOf(u,9);
    if(threat){ // scatter AWAY from the attacker with a homeward drift — no more conga lines
      const tc=TCPOS[u.team];
      let fx=u.root.position.x-threat.root.position.x, fz=u.root.position.z-threat.root.position.z;
      const fl=Math.hypot(fx,fz)||1; fx/=fl; fz/=fl;
      fx+=(tc[0]-u.root.position.x)*0.004+Math.sin(u.id*7.3)*0.35;
      fz+=(tc[1]-u.root.position.z)*0.004+Math.cos(u.id*5.1)*0.35;
      moveUnit(u,fx,fz,dt);
      return;
    }
    if(u.convertTo){
      const bar=nearestBuilt(u.team,u.convertAt||"barracks",u.root.position.x,u.root.position.z);
      if(!bar){ // barracks fell: refund the team
        stock[u.team].food+=CLS[u.convertTo].cost.food||0;
        stock[u.team].gold+=CLS[u.convertTo].cost.gold||0;
        if(u.team===BLUE)updateResHud();
        u.convertTo=null;return;
      }
      // v134.4 …AND THE ARM-UP HAD THE SAME BUG, worse. This aimed at (bar.x+3, bar.z+3) — 4.24
      // off centre, inside a barracks that blocks to 10.9 — and declared arrival within
      // bStand(def,4) = 9.96. Near side 7.36 clears it; FAR SIDE 15.84 does not, so a citizen that
      // walked up to its barracks from the wrong quarter stood outside it holding a paid-for
      // conversion for the rest of the match. The team's food and gold were already spent.
      const _adx=u.root.position.x-bar.x,_adz=u.root.position.z-bar.z,_al=Math.hypot(_adx,_adz)||1;
      if(moveToward(u,bar.x+_adx/_al*(bSurf(bar.def)+1.2),bar.z+_adz/_al*(bSurf(bar.def)+1.2),dt,1.6)){
        setClass(u,u.convertTo);u.convertTo=null;u.convertAt=null;
        // v134.4: the ox hauls TIMBER and nothing else — the same rule the human ox plays by
        // (06-input.js:466, "the ox hauls TIMBER, nothing else"). Set here rather than at the
        // decision, because until this frame the body was still a villager working its old face.
        if(u.cls==="oxcart"&&u.bot){u.bot.res="wood";u.bot.node=null;u.bot.haul=false;}
        if(u.team===BLUE&&Math.random()<0.4&&dist(u,player)<50)
          msg(u.cls==="oxcart"?(u.name+" yoked an ox at the Storage Pit.")
                              :(u.name+" armed up as a "+CLS[u.cls].name+"."),"blue");
      }
      return;
    }
    if(u.task){
      const s=u.task.site;
      if(!s.alive||s.built){u.task=null;return;}
      // stand at the NEAREST point of the site's ring, from whichever side we came —
      // a fixed east-side stand point sat OFF THE MAP for red's border-town sites
      const rdx=u.root.position.x-s.x, rdz=u.root.position.z-s.z, rl=Math.hypot(rdx,rdz)||1;
      const standX=s.x+rdx/rl*(bSurf(s.def)+0.9), standZ=s.z+rdz/rl*(bSurf(s.def)+0.9);
      if(moveToward(u,standX,standZ,dt,1.3)){
        u.facing=Math.atan2(s.x-u.root.position.x,s.z-u.root.position.z);
        u.buildT=(u.buildT||0)+dt;
        if(u.buildT>0.5){u.buildT=0;addConstructionHit(s,u);}
      }
      return;
    }
    // gather — but ripe corn beats berry-picking
    if(b.res==="food"){
      let rf=null,rd=40*40;
      for(const f of buildings){
        if(f.team!==u.team||!f.alive||!f.built||f.type!=="farm"||!(f.crop>=1))continue;
        const d=dist2(u.root.position.x,u.root.position.z,f.x,f.z);
        if(d<rd){rd=d;rf=f;}
      }
      if(rf){
        if(moveToward(u,rf.x+1.5,rf.z+1,dt,rf.def.r-1.5)&&rf.crop>=1){
          rf.crop=0;
          if(rf.cropMesh){rf.cropMesh.scale.y=0.15;for(const t of rf.tassels)t.visible=false;}
          stock[u.team].food+=20;
          if(u.team===BLUE)updateResHud();
        }
        return;
      }
    }
    // gather
    if(!b.node||b.node.amount<=0){
      b.node=botFindNode(u,b.res);
      // v134.4 …BUT THE OX DOES NOT ROTATE. A villager whose seam runs out moves to the next
      // resource; an ox that did would stand at a gold vein it cannot touch (06-input.js and
      // driveRemote both refuse any node but wood), gathering nothing, forever.
      if(!b.node&&u.cls==="oxcart")return; // no timber standing: the wain waits
      if(!b.node){b.res=b.res==="food"?"wood":b.res==="wood"?"gold":b.res==="gold"?"stone":"food";b.node=botFindNode(u,b.res);}
      if(!b.node)return; // the land is bare
      b.off={x:(Math.random()-0.5)*3.5,z:(Math.random()-0.5)*3.5};
    }
    // hands full? haul the load home — no more telepathic deposits
    const ctot=u.carry.food+u.carry.gold+u.carry.stone+u.carry.wood;
    // v134.4: the ox bed takes 300 (carryCap), and the whole point of it is the walking it saves —
    // a wain that trudged home at 20 would be a slower villager that cost 75 gold.
    const _cap=(u.cls==="oxcart")?carryCap(u):20;
    if(b.haul||ctot>=_cap){
      b.haul=true;
      const dp=nearestDropoff(u);
      if(!dp)return;
      // v134.4 STAND ON THE NEAR SIDE OF THE STORE, WHICHEVER SIDE THAT IS. This read
      //     moveToward(u,dp.x+2.5,dp.z+2,dt,bStand(dp.def,dp.type==="storage_pit"?6.5:9))
      // — a fixed corner of the building, three paces off centre and INSIDE its collider. A pit
      // blocks to 6.9, so the nearest legal ground is 3.7 from that point on the north-east side
      // and 10.1 from it on the south-west, against a tolerance of about 6.8. Come at the store
      // from the wrong quarter and arrival is geometrically impossible: the hauler stalls nine
      // paces out, the v134.0 watchdog sidesteps it, it walks back and stalls again, and it carries
      // those twenty logs for the rest of the match. Benched at 0 wood banked in five minutes — and
      // 0 on pristine v133 as well, so this is an old bug that v134.0 only changed the sound of.
      // The builder's stand point three hundred lines up was given exactly this fix at v134.0.
      const _rdx=u.root.position.x-dp.x, _rdz=u.root.position.z-dp.z, _rl=Math.hypot(_rdx,_rdz)||1;
      const _sx=dp.x+_rdx/_rl*(bSurf(dp.def)+1.2), _sz=dp.z+_rdz/_rl*(bSurf(dp.def)+1.2);
      if(moveToward(u,_sx,_sz,dt,1.6)){
        stock[u.team].food+=u.carry.food; stock[u.team].gold+=u.carry.gold;
        stock[u.team].stone+=u.carry.stone; stock[u.team].wood+=u.carry.wood;
        u.carry.food=0;u.carry.gold=0;u.carry.stone=0;u.carry.wood=0;
        if(u.team===BLUE)updateResHud();
        b.haul=false;
      }
      return;
    }
    if(moveToward(u,b.node.x+b.off.x,b.node.z+b.off.z,dt,0.9)){
      u.facing=Math.atan2(b.node.x-u.root.position.x,b.node.z-u.root.position.z);
      b.gT=(b.gT||0)+dt;
      if(b.gT>0.75*(b.node.slow||1)){
        // v134.4: FOUR at a swing for the ox — the same figure the human ox takes in 09-main.js:120
        // and a guest's in 10-net.js:1245. The swing TIME is unchanged, so the axe is four times the
        // villager's. Three copies of one number, and they now agree on the clamp as well.
        // v134.8 …AND NEVER MORE THAN THE BED HAS ROOM FOR. This clamped against the SEAM alone.
        // 300 is exactly 75 bites of four so a full load lands on the cap dead-on — until a tree
        // runs dry mid-load and truncates one bite to 3. The ox is then on 299 and the next full
        // bite makes 303. Found on SMOKE_SEED=99, bounded at 3, and the only flat rule the economy
        // gates have. The other two copies have clamped on `cap - carry` since v99; this one did not.
        const _room=carryCap(u)-(u.carry.food+u.carry.gold+u.carry.stone+u.carry.wood);
        const _tk=Math.max(0,Math.min((u.cls==="oxcart")?4:1,b.node.amount,_room));
        b.gT=0;b.node.amount-=_tk;
        u.carry[b.node.type]+=_tk;
        u.swing=0.2;
        if(b.node.amount<=0){depleteNode(b.node);b.node=null;}
      }
    }
    return;
  }
  // PRIESTS: stay with the group; on a CHARGE they advance behind the line to mend it
  if(CLS[u.cls].line==="healer"){
    if(u.chargeTo&&u.rally){
      moveToward(u,u.chargeTo.x+(u.spread||0)*0.3,u.chargeTo.z+(u.spread||0)*0.3,dt,6);
      return;
    }
    {const ld=u.rally?rallyLeaderFor(u):null; // v95: follow YOUR leader, not whoever blew a horn last
    if(ld){
      if(dist(u,ld)>6)moveToward(u,ld.root.position.x+u.spread*0.2,ld.root.position.z+u.spread*0.2,dt,5);
      return;
    }}
    const k0=kings[u.team];
    const gx=k0.root.position.x+Math.cos(u.guardA)*u.guardR;
    const gz=k0.root.position.z+Math.sin(u.guardA)*u.guardR;
    moveToward(u,gx,gz,dt,1.6);
    return;
  }
  // SIEGE ENGINES: bombard structures, creep with the army, never chase troops
  if(isSiege(u.cls)){
    if(u.raiding&&u.hp<u.maxHp*0.2)u.raiding=false;
    if(u.raiding){
      const etc=TCPOS[1-u.team];
      if(!tryAttack(u))
        moveToward(u,etc[0]+(u.team===BLUE?14:-14)+u.spread*0.5,etc[1]+u.spread,dt,
          CLS[u.cls].line==="meleesiege"?6:16);
      return;
    }
    const sbd=u.bandRef; // the siege train rolls on the enemy base, escorts in tow
    if(sbd&&sbd.role==="siege"&&!sbd.defend&&u.hp>u.maxHp*0.25){
      const etc=TCPOS[1-u.team];
      const _sg=etc[0]+(u.team===BLUE?14:-14);
      const _sa=laneTarget(u,_sg,etc[1]); // v113: the train rolls up its band's lane, not the road
      if(!tryAttack(u))
        moveToward(u,_sa.x+u.spread*0.5,_sa.z+u.spread,dt,
          _sa.lane?6:(CLS[u.cls].line==="meleesiege"?6:16));
      return;
    }
    if(u.chargeTo&&u.rally){ // siege rolls with the charge and bombards whatever it meets
      if(!tryAttack(u))moveToward(u,u.chargeTo.x+(u.spread||0)*0.4,u.chargeTo.z+(u.spread||0)*0.4,dt,7);
      return;
    }
    {const ld=u.rally?rallyLeaderFor(u):null; // v95: the siege train follows ITS leader
    if(ld){
      if(!tryAttack(u)&&dist(u,ld)>9)
        moveToward(u,ld.root.position.x+u.spread*0.3,ld.root.position.z+u.spread*0.3,dt,8);
      return;
    }}
    const k=kings[u.team];
    const gx=k.root.position.x+Math.cos(u.guardA)*(u.guardR+6);
    const gz=k.root.position.z+Math.sin(u.guardA)*(u.guardR+6);
    if(!tryAttack(u))moveToward(u,gx,gz,dt,2);
    return;
  }
  // MILITARY
  if(u.raiding&&u.hp<u.maxHp*0.25)u.raiding=false;
  if(u.raiding){raidEnemyBase(u,dt);return;}
  if(u.chargeTo&&u.rally){ // THE CHARGE: attack-move — savage everything on the way, then HOLD the far ground
    if(!engageNearest(u,dt,16)){
      const bb=nearestEnemyBuilding(u,12); // buildings in the path fall too
      if(bb){moveToward(u,bb.x,bb.z,dt,u.rng+bSurf(bb.def)-0.6);tryAttack(u);}
      else moveToward(u,u.chargeTo.x+(u.spread||0)*0.25,u.chargeTo.z+(u.spread||0)*0.25,dt,4);
    }
    return;
  }
  {const ld=u.rally?rallyLeaderFor(u):null; // v95: soldiers march under THEIR OWN banner
  if(ld){
    if(!engageNearest(u,dt,16)){
      if(dist(u,ld)>6)
        moveToward(u,ld.root.position.x+u.spread*0.25,ld.root.position.z+u.spread*0.25,dt,5);
    }
    return;
  }}
  // ---------------- WARBAND MISSIONS ----------------
  const bd=u.bandRef;
  if(bd&&bd.role!=="kingsguard"){
    const px=u.root.position.x,pz=u.root.position.z;
    if(bd.defend){ // the throne calls
      if(!engageNearest(u,dt,15)){
        const k=kings[u.team];
        moveToward(u,k.root.position.x+u.spread*0.4,k.root.position.z+u.spread*0.4,dt,5);
      }
      return;
    }
    if(bd.aid&&T<bd.aid.until){ // answer the burning farm
      if(!engageNearest(u,dt,16))moveToward(u,bd.aid.x+u.spread*0.3,bd.aid.z+u.spread*0.3,dt,(bd.aid.r||0.8)+2.2);
      return;
    }
    if(bd.role==="patrol"){
      const wp=bd.wps?bd.wps[bd.wi]:null;
      if(wp&&!engageNearest(u,dt,14))moveToward(u,wp.x+u.spread*0.35,wp.z+u.spread*0.35,dt,3);
      return;
    }
    if(bd.role==="hold"){
      const p=bd.point;
      if(p){
        if(dist2(px,pz,p.x,p.z)>24*24)moveToward(u,p.x+u.spread*0.3,p.z+u.spread*0.3,dt,3); // leash first
        else if(!engageNearest(u,dt,16))moveToward(u,p.x+u.spread*0.35,p.z+u.spread*0.35,dt,2.5);
      }
      return;
    }
    if(bd.role==="camp"){ // into the wilds, and stand on the loot when the pack is down
      const st=bd.camp;
      if(st){
        // The pack aggros on proximity, so walking in IS the attack. Stand at the centre once it is
        // down: campTick hands the chest to any non-neutral body within 2.6 of it, so collecting is
        // a matter of being there rather than of code.
        if(!engageNearest(u,dt,16))
          moveToward(u,st.x+u.spread*0.25,st.z+u.spread*0.25,dt,st.chest?1.6:4);
      }else if(!engageNearest(u,dt,14)){
        const k=kings[u.team];
        moveToward(u,k.root.position.x+u.spread*0.4,k.root.position.z+u.spread*0.4,dt,5);
      }
      return;
    }
    if(bd.role==="econ"){ // wolves among the sheep
      const t=bd.target;
      if(t&&t.unit&&t.unit.alive){
        if(!engageNearest(u,dt,10)){
          moveToward(u,t.unit.root.position.x+u.spread*0.2,t.unit.root.position.z+u.spread*0.2,dt,1.4);
          tryAttack(u);
        }
      }else if(t&&t.bld&&t.bld.alive){
        if(!engageNearest(u,dt,12)){moveToward(u,t.bld.x,t.bld.z,dt,u.rng+bSurf(t.bld.def)-0.6);tryAttack(u);}
      }else if(!engageNearest(u,dt,14)){ // between jobs: prowl the frontier — ON THIS BAND'S LANE
        const et=TCPOS[1-u.team], mx=(TCPOS[u.team][0]+et[0])/2, mz=(TCPOS[u.team][1]+et[1])/2;
        const _ez=Math.max(-LANE_EDGE,Math.min(LANE_EDGE,mz+laneFor(u))); // v113: the frontier is a LINE, not a point
        moveToward(u,mx+u.spread,_ez+u.spread,dt,7);
      }
      return;
    }
    if(bd.role==="assassin"){ // regicide is the whole game
      const ek=kings[1-u.team];
      if(ek&&ek.alive){
        if(dist(u,ek)<14){
          moveToward(u,ek.root.position.x+u.spread*0.15,ek.root.position.z+u.spread*0.15,dt,1.4);
          tryAttack(u);
        }else if(!engageNearest(u,dt,11)){
          const _ka=laneTarget(u,ek.root.position.x,ek.root.position.z); // v113: killers come in off the flank too
          moveToward(u,_ka.x+u.spread*0.25,_ka.z+u.spread*0.25,dt,_ka.lane?6:2.2);
        }
      }
      return;
    }
    if(bd.role==="siege"){ // escorts shepherd the engines
      let cx=0,cz=0,n=0;
      for(const v of bd.members)if(isSiege(v.cls)&&v.alive){cx+=v.root.position.x;cz+=v.root.position.z;n++;}
      if(n){
        cx/=n;cz/=n;
        if(dist2(px,pz,cx,cz)>10*10)moveToward(u,cx+u.spread*0.4,cz+u.spread*0.4,dt,4);
        else engageNearest(u,dt,16);
      }else if(!engageNearest(u,dt,16))raidEnemyBase(u,dt); // engines lost: fight on
      return;
    }
  }
  // defend the crown AND the town — one raider can no longer hold the base hostage
  const k=kings[u.team];
  const tc0=teamTC(u.team);
  let homeThreat=nearestEnemyOf(k,26);
  if(!homeThreat&&tc0){
    for(const v of units){
      if(v.team===u.team||!v.alive)continue;
      if(dist2(tc0.x,tc0.z,v.root.position.x,v.root.position.z)<30*30){homeThreat=v;break;}
    }
  }
  if(homeThreat){engageNearest(u,dt,70);return;}
  if(!engageNearest(u,dt,14)){
    const gx=k.root.position.x+Math.cos(u.guardA)*u.guardR;
    const gz=k.root.position.z+Math.sin(u.guardA)*u.guardR;
    moveToward(u,gx,gz,dt,1.6);
  }
}

// ---------- crowd separation ----------
function separate(){
  // v134.0 …AND WHAT IT SHOVES, IT SETTLES. This wrote root.position directly — no walkable test,
  // no building push-out, no clamp — and it is the LAST thing in the frame, after every bot has
  // moved (09-main.js). So the closing act of every frame was to teleport NPC bodies INTO building
  // footprints; moveUnit squirted them out on the next; separate() put them back. A ten-deep queue
  // of villagers at a Town Center can carry a body several units in one pass, far past the 0.7 the
  // collider allows, and the pair ran forever. This is John's "AI gets severely stuck around all
  // buildings", and it is why the stall detector never fired: net progress was zero while realized
  // displacement was large, which is precisely the case the old detector could not see.
  //
  // The shoves themselves are untouched — the crowd still parts, players are still anchors. What
  // changes is that every body the pass MOVED is then resolved against the same collider moveUnit
  // uses, and a body that cannot be resolved onto legal ground is put back where it stood. The map
  // is built lazily: on a quiet frame nothing overlaps and nothing is allocated.
  let pre=null;
  const mark=(v)=>{if(!pre)pre=new Map();
    if(!pre.has(v))pre.set(v,{x:v.root.position.x,z:v.root.position.z});};
  for(let i=0;i<units.length;i++){
    const a=units[i];if(!a.alive)continue;
    const aAnchor=a.isPlayer||a.remote; // player bodies are anchors: crowds part around THEM
    const ap=a.root.position;
    for(let j=i+1;j<units.length;j++){
      const c=units[j];if(!c.alive)continue;
      const cAnchor=c.isPlayer||c.remote;
      if(aAnchor&&cAnchor)continue; // two players may stand shoulder to shoulder
      const cp=c.root.position;
      const dx=cp.x-ap.x,dz=cp.z-ap.z,d2=dx*dx+dz*dz;
      if(d2<1.69&&d2>0.0001){
        const d=Math.sqrt(d2),push=(1.3-d)*0.4,px=dx/d*push,pz=dz/d*push;
        // an unpredictable host-side shove on a player's body IS the rubber band —
        // so the full push lands on the NPC instead
        if(aAnchor){mark(c);cp.x+=px*1.5;cp.z+=pz*1.5;}
        else if(cAnchor){mark(a);ap.x-=px*1.5;ap.z-=pz*1.5;}
        else{mark(a);mark(c);ap.x-=px;ap.z-=pz;cp.x+=px;cp.z+=pz;}
      }
    }
  }
  if(pre)for(const [v,p0] of pre){
    const p=v.root.position;
    const q=pushOutOfBuildings(v,p.x,p.z,0,0,0); // dt 0: eject, do not slide — nobody is walking
    if(walkable(q[0],q[1])){p.x=q[0];p.z=q[1];}
    else{p.x=p0.x;p.z=p0.z;} // the crowd shoved this body off the world: it keeps its ground
  }
  settleIdle();
}
// v134.0 THE IDLE ARE SETTLED TOO. moveUnit resolves a body that is TRYING TO MOVE and the pass
// above resolves a body a crowd has just SHOVED. Nothing touched a body standing inside geometry
// and staying there — and bodies get there without walking: spawnTeam scatters the opening fifty on
// a radius of 13-25 while a Town Center's box half-diagonal is 16.56, a building's box GROWS under
// its neighbours as the town ages (a Classical->Medieval barracks: 6.70 -> 10.00), and a villager
// whose resource runs dry returns from updateBot without moving at all. Any of those and the body
// is indoors for the rest of the match.
//
// A tenth of the army a frame, round-robin: the full collider loop is O(buildings), and paying it
// for every idle body every frame would cost more than the problem. Nothing here is random, so the
// order is the same on every machine and in every replay.
let _settleAt=0;
const SETTLE_SLICE=10;      // frames to walk the whole roster in — 1/3 of a second at 30fps
const SETTLE_QUIET=0.3;     // moved this recently? moveUnit owns it, leave it alone
function settleIdle(){
  const N=units.length; if(!N)return;
  const slice=Math.max(1,Math.ceil(N/SETTLE_SLICE));
  for(let k=0;k<slice;k++){
    const v=units[(_settleAt+k)%N];
    if(!v||!v.alive||v.isPlayer||v.remote||v.garrison)continue; // a player's body is never ours to
    if(T-(v._mv||-1e4)<SETTLE_QUIET)continue;                   // shove; a garrison CLIMBED in
    const p=v.root.position;
    const q=pushOutOfBuildings(v,p.x,p.z,0,0,0);
    if(q[0]===p.x&&q[1]===p.z)continue;                         // already standing somewhere legal
    if(walkable(q[0],q[1])){p.x=q[0];p.z=q[1];}
  }
  _settleAt=(_settleAt+slice)%N;
}
function updateRoster(){
  let bv=0,bm=0,rv=0,rm=0;
  for(const u of units){
    if(!u.alive||u.isKing)continue;
    // v124: there are THREE teams. The old two-way ternary sent every NEUTRAL creep — 24 live
    // barbarians, wolves and vikings — into RED's column, and since no creep is a villager they
    // all landed on RED's military count. John's field shots showed a constant 73-vs-49 gap that
    // was exactly the wilds population. The wilds belong to nobody: count them for neither crown.
    // v134.4: ⚠ THIS NUMBER CHANGES ON SCREEN. A trade cart has always been counted in the MILITARY
    // column here, and an ox would have been too. Neither carries a weapon.
    if(u.team===BLUE){isWorker(u)?bv++:bm++;}
    else if(u.team===RED){isWorker(u)?rv++:rm++;}
  }
  // v124.9: on a phone this line shows YOUR team only. Two reasons, and the second is the real one:
  // the age was already spelled out in its own segment two boxes to the left, and knowing the
  // enemy's exact villager/soldier split is information a player should have to SCOUT for.
  // v125: John's call, and he took it — the same rule now applies on desktop. The condition below
  // is "is the HUD the compact one-bar layout", which is true in touch-mode (12-touch) and in
  // bar-mode (13-deskui). The long form survives for ?ui=classic only.
  // (The class is read at CALL time, not load time, so it does not matter that both of those files
  // load after this one.)
  if(typeof document!=="undefined"&&document.documentElement&&
     (document.documentElement.classList.contains("touch-mode")||
      document.documentElement.classList.contains("bar-mode"))){
    const mv=(MYTEAM===BLUE)?bv:rv, mm=(MYTEAM===BLUE)?bm:rm;
    const col=(MYTEAM===BLUE)?"#2f57c9":"#b4291b";
    document.getElementById("roster").innerHTML=
      "<span style='color:"+col+"'>■</span> ⛏ "+mv+" · ⚔ "+mm;
    return;
  }
  document.getElementById("roster").innerHTML=
    "<span style='color:#3d6ef2'>■</span> ⛏ "+bv+" · ⚔ "+bm+" · "+AGES[teamAge[BLUE]].name.split(" ")[0].toUpperCase()+
    " &nbsp;&nbsp;<span style='color:#d94a3d'>■</span> ⛏ "+rv+" · ⚔ "+rm+" · "+AGES[teamAge[RED]].name.split(" ")[0].toUpperCase();
}
